import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { receitaSchema, itemReceitaSchema, producaoReceitaSchema } from "@/lib/validations";
import type { Receita, MateriaPrima, ItemReceita } from "@shared/schema";
import { Plus, Edit, Trash2, BookOpen, Factory, Eye } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function Receitas() {
  const [editingItem, setEditingItem] = useState<Receita | null>(null);
  const [viewingItem, setViewingItem] = useState<Receita | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isProducaoDialogOpen, setIsProducaoDialogOpen] = useState(false);
  const [isItemDialogOpen, setIsItemDialogOpen] = useState(false);
  const [selectedReceita, setSelectedReceita] = useState<Receita | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: receitas, isLoading } = useQuery<Receita[]>({
    queryKey: ['/api/receitas']
  });

  const { data: materiasPrimas } = useQuery<MateriaPrima[]>({
    queryKey: ['/api/materias-primas']
  });

  const { data: itensReceita } = useQuery<(ItemReceita & { materiaPrima: MateriaPrima })[]>({
    queryKey: ['/api/receitas', viewingItem?.id, 'itens'],
    enabled: !!viewingItem?.id
  });

  const form = useForm({
    resolver: zodResolver(receitaSchema),
    defaultValues: {
      nome: "",
      descricao: "",
      unidadeSaida: "",
      rendimentoPadrao: "1",
      custoEstimado: "0"
    }
  });

  const itemForm = useForm({
    resolver: zodResolver(itemReceitaSchema),
    defaultValues: {
      materiaPrimaId: "",
      quantidade: "",
      unidade: ""
    }
  });

  const producaoForm = useForm({
    resolver: zodResolver(producaoReceitaSchema),
    defaultValues: {
      receitaId: "",
      quantidadeProduzir: ""
    }
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/receitas', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Receita criada com sucesso"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest('PUT', `/api/receitas/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas'] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({
        title: "Sucesso", 
        description: "Receita atualizada com sucesso"
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/receitas/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas'] });
      toast({
        title: "Sucesso",
        description: "Receita removida com sucesso"
      });
    }
  });

  const addItemMutation = useMutation({
    mutationFn: ({ receitaId, data }: { receitaId: string; data: any }) =>
      apiRequest('POST', `/api/receitas/${receitaId}/itens`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas', viewingItem?.id, 'itens'] });
      setIsItemDialogOpen(false);
      itemForm.reset();
      toast({
        title: "Sucesso",
        description: "Item adicionado à receita"
      });
    }
  });

  const removeItemMutation = useMutation({
    mutationFn: (itemId: string) => apiRequest('DELETE', `/api/receitas/itens/${itemId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas', viewingItem?.id, 'itens'] });
      toast({
        title: "Sucesso",
        description: "Item removido da receita"
      });
    }
  });

  const producaoMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/producao/receita', {
      receitaId: data.receitaId,
      quantidadeProduzir: parseFloat(data.quantidadeProduzir)
    }),
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas'] });
      setIsProducaoDialogOpen(false);
      producaoForm.reset();
      toast({
        title: "Sucesso",
        description: response.message || "Produção realizada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro na produção",
        description: error.message
      });
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data });
    } else {
      createMutation.mutate(data);
    }
  });

  const handleEdit = (item: Receita) => {
    setEditingItem(item);
    form.reset({
      nome: item.nome,
      descricao: item.descricao || "",
      unidadeSaida: item.unidadeSaida,
      rendimentoPadrao: item.rendimentoPadrao,
      custoEstimado: item.custoEstimado
    });
    setIsDialogOpen(true);
  };

  const handleView = (item: Receita) => {
    setViewingItem(item);
    setIsViewDialogOpen(true);
  };

  const handleProducao = (item: Receita) => {
    setSelectedReceita(item);
    producaoForm.setValue("receitaId", item.id);
    setIsProducaoDialogOpen(true);
  };

  const handleAddItem = itemForm.handleSubmit((data) => {
    if (viewingItem) {
      addItemMutation.mutate({ receitaId: viewingItem.id, data });
    }
  });

  const handleProducaoSubmit = producaoForm.handleSubmit((data) => {
    producaoMutation.mutate(data);
  });

  const columns: ColumnDef<Receita>[] = [
    {
      accessorKey: "nome",
      header: "Nome"
    },
    {
      accessorKey: "unidadeSaida",
      header: "Unidade",
      cell: ({ row }) => row.getValue("unidadeSaida")
    },
    {
      accessorKey: "estoqueAtual",
      header: "Estoque",
      cell: ({ row }) => {
        const estoque = parseFloat(row.getValue("estoqueAtual"));
        const unidade = row.original.unidadeSaida;
        return `${estoque} ${unidade}`;
      }
    },
    {
      accessorKey: "rendimentoPadrao",
      header: "Rendimento",
      cell: ({ row }) => {
        const rendimento = parseFloat(row.getValue("rendimentoPadrao"));
        const unidade = row.original.unidadeSaida;
        return `${rendimento} ${unidade}`;
      }
    },
    {
      accessorKey: "custoEstimado",
      header: "Custo Est.",
      cell: ({ row }) => `R$ ${parseFloat(row.getValue("custoEstimado")).toFixed(2)}`
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleView(row.original)}
            data-testid={`view-${row.original.id}`}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleEdit(row.original)}
            data-testid={`edit-${row.original.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleProducao(row.original)}
            data-testid={`produce-${row.original.id}`}
          >
            <Factory className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <Topbar 
        title="Receitas" 
        description="Gestão de receitas e ingredientes"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Receitas</p>
                  <p className="text-2xl font-bold" data-testid="total-receitas">
                    {receitas?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Factory className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Em Estoque</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="receitas-estoque">
                    {receitas?.filter(r => parseFloat(r.estoqueAtual) > 0).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      setEditingItem(null);
                      form.reset();
                    }}
                    data-testid="button-nova-receita"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Receita
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingItem ? "Editar Receita" : "Nova Receita"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="nome"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Ex: Brigadeiro de Cacau"
                                data-testid="input-nome"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="descricao"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Descrição</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Descrição da receita..."
                                data-testid="input-descricao"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="unidadeSaida"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Unidade de Saída *</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-unidade-saida">
                                    <SelectValue placeholder="Selecione" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="porção">Porção</SelectItem>
                                  <SelectItem value="unidade">Unidade</SelectItem>
                                  <SelectItem value="kg">Quilogramas (kg)</SelectItem>
                                  <SelectItem value="g">Gramas (g)</SelectItem>
                                  <SelectItem value="L">Litros (L)</SelectItem>
                                  <SelectItem value="ml">Mililitros (ml)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="rendimentoPadrao"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Rendimento Padrão</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.001"
                                  placeholder="1"
                                  data-testid="input-rendimento-padrao"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="custoEstimado"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Custo Estimado (R$)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number"
                                step="0.01"
                                placeholder="0.00"
                                data-testid="input-custo-estimado"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end gap-4 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsDialogOpen(false)}
                          data-testid="button-cancelar"
                        >
                          Cancelar
                        </Button>
                        <Button
                          type="submit"
                          disabled={createMutation.isPending || updateMutation.isPending}
                          data-testid="button-salvar"
                        >
                          {createMutation.isPending || updateMutation.isPending 
                            ? "Salvando..." 
                            : "Salvar"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={receitas || []}
                searchPlaceholder="Buscar receitas..."
              />
            )}
          </CardContent>
        </Card>

        {/* View Recipe Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Receita: {viewingItem?.nome}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold">Informações</h4>
                  <p><strong>Unidade:</strong> {viewingItem?.unidadeSaida}</p>
                  <p><strong>Rendimento:</strong> {viewingItem?.rendimentoPadrao}</p>
                  <p><strong>Estoque:</strong> {viewingItem?.estoqueAtual}</p>
                  <p><strong>Custo:</strong> R$ {parseFloat(viewingItem?.custoEstimado || "0").toFixed(2)}</p>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">Ingredientes</h4>
                  <Dialog open={isItemDialogOpen} onOpenChange={setIsItemDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" data-testid="button-add-ingredient">
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Ingrediente
                      </Button>
                    </DialogTrigger>
                    
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Adicionar Ingrediente</DialogTitle>
                      </DialogHeader>
                      
                      <Form {...itemForm}>
                        <form onSubmit={handleAddItem} className="space-y-4">
                          <FormField
                            control={itemForm.control}
                            name="materiaPrimaId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Matéria-Prima *</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-materia-prima">
                                      <SelectValue placeholder="Selecione" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {materiasPrimas?.map(mp => (
                                      <SelectItem key={mp.id} value={mp.id}>
                                        {mp.nome} ({mp.unidade})
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={itemForm.control}
                              name="quantidade"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Quantidade *</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number"
                                      step="0.001"
                                      placeholder="0"
                                      data-testid="input-quantidade-item"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={itemForm.control}
                              name="unidade"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Unidade *</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="Ex: kg, g, ml"
                                      data-testid="input-unidade-item"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="flex justify-end gap-4">
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => setIsItemDialogOpen(false)}
                            >
                              Cancelar
                            </Button>
                            <Button
                              type="submit"
                              disabled={addItemMutation.isPending}
                            >
                              {addItemMutation.isPending ? "Adicionando..." : "Adicionar"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="space-y-2">
                  {itensReceita?.map(item => (
                    <div 
                      key={item.id} 
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <span className="font-medium">{item.materiaPrima.nome}</span>
                        <span className="text-muted-foreground ml-2">
                          {parseFloat(item.quantidade)} {item.unidade}
                        </span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeItemMutation.mutate(item.id)}
                        disabled={removeItemMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )) || <p className="text-muted-foreground">Nenhum ingrediente adicionado</p>}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Production Dialog */}
        <Dialog open={isProducaoDialogOpen} onOpenChange={setIsProducaoDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Produzir Receita: {selectedReceita?.nome}</DialogTitle>
            </DialogHeader>
            
            <Form {...producaoForm}>
              <form onSubmit={handleProducaoSubmit} className="space-y-4">
                <FormField
                  control={producaoForm.control}
                  name="quantidadeProduzir"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantidade a Produzir</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          step="0.001"
                          placeholder="0"
                          data-testid="input-quantidade-produzir"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="text-sm text-muted-foreground">
                  <p><strong>Rendimento padrão:</strong> {selectedReceita?.rendimentoPadrao} {selectedReceita?.unidadeSaida}</p>
                  <p><strong>Estoque atual:</strong> {selectedReceita?.estoqueAtual} {selectedReceita?.unidadeSaida}</p>
                </div>

                <div className="flex justify-end gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsProducaoDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={producaoMutation.isPending}
                    data-testid="button-confirmar-producao"
                  >
                    {producaoMutation.isPending ? "Produzindo..." : "Confirmar Produção"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
