import { z } from "zod";

export const materiaPrimaSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  categoria: z.string().optional(),
  unidade: z.string().min(1, "Unidade é obrigatória"),
  estoqueAtual: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Estoque deve ser um número positivo"),
  estoqueMinimo: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Estoque mínimo deve ser um número positivo"),
  custoUnitario: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Custo deve ser um número positivo"),
  fornecedor: z.string().optional(),
  observacoes: z.string().optional()
});

export const receitaSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  descricao: z.string().optional(),
  unidadeSaida: z.string().min(1, "Unidade de saída é obrigatória"),
  rendimentoPadrao: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Rendimento deve ser maior que zero"),
  custoEstimado: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Custo deve ser um número positivo")
});

export const itemReceitaSchema = z.object({
  materiaPrimaId: z.string().min(1, "Matéria-prima é obrigatória"),
  quantidade: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Quantidade deve ser maior que zero"),
  unidade: z.string().min(1, "Unidade é obrigatória")
});

export const produtoSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  descricao: z.string().optional(),
  precoVenda: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Preço deve ser um número positivo"),
  unidade: z.string().optional()
});

export const componenteProdutoSchema = z.object({
  receitaId: z.string().optional(),
  embalagemId: z.string().optional(),
  quantidade: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Quantidade deve ser maior que zero")
}).refine(data => data.receitaId || data.embalagemId, {
  message: "Deve selecionar uma receita ou embalagem"
});

export const embalagemSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  tipo: z.string().optional(),
  unidade: z.string().optional(),
  estoqueAtual: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Estoque deve ser um número positivo"),
  custoUnitario: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Custo deve ser um número positivo")
});

export const clienteSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  telefone: z.string().optional(),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  aniversario: z.date().optional()
});

export const pedidoSchema = z.object({
  clienteId: z.string().min(1, "Cliente é obrigatório"),
  canal: z.string().optional(),
  dataEntrega: z.date(),
  observacoes: z.string().optional(),
  totalBruto: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Total deve ser um número positivo"),
  desconto: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Desconto deve ser um número positivo"),
  totalLiquido: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Total líquido deve ser um número positivo")
});

export const itemPedidoSchema = z.object({
  produtoId: z.string().min(1, "Produto é obrigatório"),
  quantidade: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Quantidade deve ser maior que zero"),
  precoUnit: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Preço deve ser um número positivo"),
  customizacoes: z.record(z.any()).optional()
});

export const producaoReceitaSchema = z.object({
  receitaId: z.string().min(1, "Receita é obrigatória"),
  quantidadeProduzir: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Quantidade deve ser maior que zero")
});

export const producaoProdutoSchema = z.object({
  produtoId: z.string().min(1, "Produto é obrigatório"),
  quantidadeProduzir: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Quantidade deve ser maior que zero")
});

export const vendaRapidaSchema = z.object({
  produtoId: z.string().min(1, "Produto é obrigatório"),
  quantidade: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Quantidade deve ser maior que zero")
});

export const configImpressorasSchema = z.object({
  impressoraRecepcao: z.string().optional(),
  impressoraCozinha: z.string().optional(),
  etiquetaLarguraMm: z.string().refine(val => val === "" || (!isNaN(parseInt(val)) && parseInt(val) > 0), "Largura deve ser um número positivo").optional(),
  etiquetaAlturaMm: z.string().refine(val => val === "" || (!isNaN(parseInt(val)) && parseInt(val) > 0), "Altura deve ser um número positivo").optional()
});
