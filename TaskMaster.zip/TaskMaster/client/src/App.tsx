import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/layout/sidebar";
import { useAuthStore } from "@/services/auth";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

// Pages
import Dashboard from "@/pages/dashboard";
import SignIn from "@/pages/auth/signin";
import MateriasPrimas from "@/pages/materias-primas";
import Receitas from "@/pages/receitas";
import Produtos from "@/pages/produtos";
import Embalagens from "@/pages/embalagens";
import Pedidos from "@/pages/pedidos";
import VendaRapida from "@/pages/venda-rapida";
import Clientes from "@/pages/clientes";
import ProducaoReceitas from "@/pages/producao/receitas";
import ProducaoProdutos from "@/pages/producao/produtos";
import Relatorios from "@/pages/relatorios";
import ConfigImpressoras from "@/pages/config/impressoras";
import NotFound from "@/pages/not-found";

function AuthenticatedApp() {
  const { user, setUser, clearUser } = useAuthStore();
  
  const { data: authData, isLoading } = useQuery({
    queryKey: ['/api/auth/me'],
    retry: false,
  });

  useEffect(() => {
    if (authData?.user) {
      setUser(authData.user);
    } else if (authData === null) {
      clearUser();
    }
  }, [authData, setUser, clearUser]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Carregando...</div>
      </div>
    );
  }

  if (!user) {
    return <SignIn />;
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/materias-primas" component={MateriasPrimas} />
          <Route path="/receitas" component={Receitas} />
          <Route path="/produtos" component={Produtos} />
          <Route path="/embalagens" component={Embalagens} />
          <Route path="/pedidos" component={Pedidos} />
          <Route path="/venda-rapida" component={VendaRapida} />
          <Route path="/clientes" component={Clientes} />
          <Route path="/producao/receitas" component={ProducaoReceitas} />
          <Route path="/producao/produtos" component={ProducaoProdutos} />
          <Route path="/relatorios" component={Relatorios} />
          <Route path="/config/impressoras" component={ConfigImpressoras} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AuthenticatedApp />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
