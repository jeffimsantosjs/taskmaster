import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { pedidoSchema, itemPedidoSchema } from "@/lib/validations";
import { formatCurrency, formatDateTime } from "@/lib/utils";
import type { Pedido, Cliente, Produto, ItemPedido } from "@shared/schema";
import { Plus, Edit, Trash2, Calendar, Factory, Printer, Eye, UserPlus } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function Pedidos() {
  const [editingItem, setEditingItem] = useState<Pedido | null>(null);
  const [viewingItem, setViewingItem] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isProducaoDialogOpen, setIsProducaoDialogOpen] = useState(false);
  const [isItemDialogOpen, setIsItemDialogOpen] = useState(false);
  const [selectedDateRange, setSelectedDateRange] = useState({ start: "", end: "" });
  const [statusFilter, setStatusFilter] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: pedidos, isLoading } = useQuery<(Pedido & { cliente: Cliente })[]>({
    queryKey: ['/api/pedidos', selectedDateRange, statusFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      if (selectedDateRange.start) params.append('dataInicio', selectedDateRange.start);
      if (selectedDateRange.end) params.append('dataFim', selectedDateRange.end);
      if (statusFilter) params.append('status', statusFilter);
      
      return fetch(`/api/pedidos?${params}`, { credentials: 'include' })
        .then(res => res.json());
    }
  });

  const { data: clientes } = useQuery<Cliente[]>({
    queryKey: ['/api/clientes']
  });

  const { data: produtos } = useQuery<Produto[]>({
    queryKey: ['/api/produtos']
  });

  const { data: pedidoDetalhes } = useQuery<any>({
    queryKey: ['/api/pedidos', viewingItem?.id],
    enabled: !!viewingItem?.id
  });

  const form = useForm({
    resolver: zodResolver(pedidoSchema),
    defaultValues: {
      clienteId: "",
      canal: "",
      dataEntrega: new Date(),
      observacoes: "",
      totalBruto: "0",
      desconto: "0", 
      totalLiquido: "0"
    }
  });

  const itemForm = useForm({
    resolver: zodResolver(itemPedidoSchema),
    defaultValues: {
      produtoId: "",
      quantidade: "1",
      precoUnit: "0",
      customizacoes: {}
    }
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/pedidos', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pedidos'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Pedido criado com sucesso"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest('PUT', `/api/pedidos/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pedidos'] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({
        title: "Sucesso", 
        description: "Pedido atualizado com sucesso"
      });
    }
  });

  const producaoMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/pedidos/produzir', data),
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/pedidos'] });
      setIsProducaoDialogOpen(false);
      toast({
        title: "Sucesso",
        description: response.message || "Pedidos colocados em produção"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const etiquetasMutation = useMutation({
    mutationFn: (pedidoId: string) => apiRequest('POST', `/api/etiquetas/${pedidoId}`),
    onSuccess: (response: any) => {
      toast({
        title: "Sucesso",
        description: response.message || "Etiquetas geradas"
      });
      
      if (response.pdfUrl) {
        // Simular download do PDF
        window.open(response.pdfUrl, '_blank');
      }
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    const formattedData = {
      ...data,
      dataEntrega: new Date(data.dataEntrega).toISOString()
    };
    
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formattedData });
    } else {
      createMutation.mutate(formattedData);
    }
  });

  const handleEdit = (item: Pedido & { cliente: Cliente }) => {
    setEditingItem(item);
    form.reset({
      clienteId: item.clienteId,
      canal: item.canal || "",
      dataEntrega: new Date(item.dataEntrega),
      observacoes: item.observacoes || "",
      totalBruto: item.totalBruto,
      desconto: item.desconto,
      totalLiquido: item.totalLiquido
    });
    setIsDialogOpen(true);
  };

  const handleView = (item: Pedido & { cliente: Cliente }) => {
    setViewingItem(item);
    setIsViewDialogOpen(true);
  };

  const handleProducao = () => {
    if (!selectedDateRange.start || !selectedDateRange.end) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Selecione o período para produção"
      });
      return;
    }
    
    producaoMutation.mutate({
      dataInicio: selectedDateRange.start,
      dataFim: selectedDateRange.end
    });
  };

  const handlePrintEtiquetas = (pedidoId: string) => {
    etiquetasMutation.mutate(pedidoId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PAGO_CONFIRMADO': return 'bg-blue-100 text-blue-800';
      case 'EM_PRODUCAO': return 'bg-yellow-100 text-yellow-800';
      case 'PRONTO': return 'bg-green-100 text-green-800';
      case 'ENTREGUE': return 'bg-gray-100 text-gray-800';
      case 'CANCELADO': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'PAGO_CONFIRMADO': return 'Confirmado';
      case 'EM_PRODUCAO': return 'Em Produção';
      case 'PRONTO': return 'Pronto';
      case 'ENTREGUE': return 'Entregue';
      case 'CANCELADO': return 'Cancelado';
      default: return status;
    }
  };

  const columns: ColumnDef<Pedido & { cliente: Cliente }>[] = [
    {
      accessorKey: "id",
      header: "ID",
      cell: ({ row }) => row.getValue("id").toString().slice(-8)
    },
    {
      header: "Cliente",
      cell: ({ row }) => row.original.cliente?.nome || "N/A"
    },
    {
      accessorKey: "dataEntrega",
      header: "Entrega",
      cell: ({ row }) => formatDateTime(row.getValue("dataEntrega"))
    },
    {
      accessorKey: "canal",
      header: "Canal",
      cell: ({ row }) => row.getValue("canal") || "-"
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => (
        <Badge className={getStatusColor(row.getValue("status"))}>
          {getStatusLabel(row.getValue("status"))}
        </Badge>
      )
    },
    {
      accessorKey: "totalLiquido",
      header: "Total",
      cell: ({ row }) => formatCurrency(parseFloat(row.getValue("totalLiquido")))
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleView(row.original)}
            data-testid={`view-${row.original.id}`}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleEdit(row.original)}
            data-testid={`edit-${row.original.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handlePrintEtiquetas(row.original.id)}
            disabled={etiquetasMutation.isPending}
            data-testid={`print-${row.original.id}`}
          >
            <Printer className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <Topbar 
        title="Pedidos Agendados" 
        description="Gestão de pedidos e agendamentos"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Filters and Actions */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex gap-2">
                <Input
                  type="date"
                  placeholder="Data início"
                  value={selectedDateRange.start}
                  onChange={(e) => setSelectedDateRange(prev => ({ ...prev, start: e.target.value }))}
                  data-testid="input-data-inicio"
                />
                <Input
                  type="date"
                  placeholder="Data fim"
                  value={selectedDateRange.end}
                  onChange={(e) => setSelectedDateRange(prev => ({ ...prev, end: e.target.value }))}
                  data-testid="input-data-fim"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48" data-testid="select-status-filter">
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos os status</SelectItem>
                  <SelectItem value="PAGO_CONFIRMADO">Confirmado</SelectItem>
                  <SelectItem value="EM_PRODUCAO">Em Produção</SelectItem>
                  <SelectItem value="PRONTO">Pronto</SelectItem>
                  <SelectItem value="ENTREGUE">Entregue</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex gap-2 ml-auto">
                <Button
                  onClick={handleProducao}
                  disabled={producaoMutation.isPending}
                  className="bg-accent hover:bg-accent/90"
                  data-testid="button-produzir-pedidos"
                >
                  <Factory className="h-4 w-4 mr-2" />
                  Produzir Pedidos
                </Button>
                
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      onClick={() => {
                        setEditingItem(null);
                        form.reset();
                      }}
                      data-testid="button-novo-pedido"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Novo Pedido
                    </Button>
                  </DialogTrigger>
                  
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingItem ? "Editar Pedido" : "Novo Pedido"}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <Form {...form}>
                      <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <h4 className="text-lg font-medium">Informações do Cliente</h4>
                            
                            <FormField
                              control={form.control}
                              name="clienteId"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Cliente *</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                      <SelectTrigger data-testid="select-cliente">
                                        <SelectValue placeholder="Selecione o cliente" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      {clientes?.map(cliente => (
                                        <SelectItem key={cliente.id} value={cliente.id}>
                                          {cliente.nome} - {cliente.telefone}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={form.control}
                              name="canal"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Canal</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                      <SelectTrigger data-testid="select-canal">
                                        <SelectValue placeholder="Selecione o canal" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                                      <SelectItem value="instagram">Instagram</SelectItem>
                                      <SelectItem value="balcao">Balcão</SelectItem>
                                      <SelectItem value="telefone">Telefone</SelectItem>
                                      <SelectItem value="site">Site</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="space-y-4">
                            <h4 className="text-lg font-medium">Detalhes do Pedido</h4>
                            
                            <FormField
                              control={form.control}
                              name="dataEntrega"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Data/Hora de Entrega *</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="datetime-local"
                                      data-testid="input-data-entrega"
                                      {...field}
                                      value={field.value instanceof Date ? 
                                        field.value.toISOString().slice(0, 16) : 
                                        field.value
                                      }
                                      onChange={(e) => field.onChange(new Date(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <div className="grid grid-cols-3 gap-2">
                              <FormField
                                control={form.control}
                                name="totalBruto"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Total Bruto</FormLabel>
                                    <FormControl>
                                      <Input 
                                        type="number"
                                        step="0.01"
                                        data-testid="input-total-bruto"
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />

                              <FormField
                                control={form.control}
                                name="desconto"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Desconto</FormLabel>
                                    <FormControl>
                                      <Input 
                                        type="number"
                                        step="0.01"
                                        data-testid="input-desconto"
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />

                              <FormField
                                control={form.control}
                                name="totalLiquido"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Total Líquido</FormLabel>
                                    <FormControl>
                                      <Input 
                                        type="number"
                                        step="0.01"
                                        data-testid="input-total-liquido"
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                        </div>

                        <FormField
                          control={form.control}
                          name="observacoes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Observações</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Observações especiais..."
                                  data-testid="input-observacoes"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end gap-4 pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsDialogOpen(false)}
                            data-testid="button-cancelar"
                          >
                            Cancelar
                          </Button>
                          <Button
                            type="submit"
                            disabled={createMutation.isPending || updateMutation.isPending}
                            data-testid="button-salvar"
                          >
                            {createMutation.isPending || updateMutation.isPending 
                              ? "Salvando..." 
                              : "Salvar"
                            }
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {['PAGO_CONFIRMADO', 'EM_PRODUCAO', 'PRONTO', 'ENTREGUE'].map(status => {
            const count = pedidos?.filter(p => p.status === status).length || 0;
            return (
              <Card key={status}>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold">{count}</p>
                    <p className="text-sm text-muted-foreground">
                      {getStatusLabel(status)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={pedidos || []}
                searchPlaceholder="Buscar pedidos..."
              />
            )}
          </CardContent>
        </Card>

        {/* View Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Pedido: {viewingItem?.id?.slice(-8)}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold">Informações do Cliente</h4>
                  <p><strong>Nome:</strong> {viewingItem?.cliente?.nome}</p>
                  <p><strong>Telefone:</strong> {viewingItem?.cliente?.telefone}</p>
                  <p><strong>Email:</strong> {viewingItem?.cliente?.email || "N/A"}</p>
                </div>
                <div>
                  <h4 className="font-semibold">Detalhes do Pedido</h4>
                  <p><strong>Canal:</strong> {viewingItem?.canal || "N/A"}</p>
                  <p><strong>Data Entrega:</strong> {formatDateTime(viewingItem?.dataEntrega)}</p>
                  <p><strong>Status:</strong> 
                    <Badge className={`ml-2 ${getStatusColor(viewingItem?.status)}`}>
                      {getStatusLabel(viewingItem?.status)}
                    </Badge>
                  </p>
                  <p><strong>Total:</strong> {formatCurrency(parseFloat(viewingItem?.totalLiquido || "0"))}</p>
                </div>
              </div>
              
              {viewingItem?.observacoes && (
                <div>
                  <h4 className="font-semibold">Observações</h4>
                  <p className="text-muted-foreground">{viewingItem.observacoes}</p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
