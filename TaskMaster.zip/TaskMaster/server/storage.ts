import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, desc, asc, like, and, gte, lte, sql } from "drizzle-orm";
import * as schema from "@shared/schema";
import type {
  User,
  InsertUser,
  MateriaPrima,
  InsertMateriaPrima,
  Receita,
  InsertReceita,
  ItemReceita,
  InsertItemReceita,
  Produto,
  InsertProduto,
  Embalagem,
  InsertEmbalagem,
  ComponenteProduto,
  InsertComponenteProduto,
  MovimentoEstoque,
  Cliente,
  InsertCliente,
  Pedido,
  InsertPedido,
  ItemPedido,
  InsertItemPedido,
  ConfigImpressoras,
  InsertConfigImpressoras
} from "@shared/schema";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error("DATABASE_URL environment variable is not set");
}

const client = postgres(connectionString);
export const db = drizzle(client, { schema });

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Matérias-primas
  getMateriasPrimas(search?: string): Promise<MateriaPrima[]>;
  getMateriaPrima(id: string): Promise<MateriaPrima | undefined>;
  createMateriaPrima(materiaPrima: InsertMateriaPrima): Promise<MateriaPrima>;
  updateMateriaPrima(id: string, materiaPrima: Partial<InsertMateriaPrima>): Promise<MateriaPrima>;
  deleteMateriaPrima(id: string): Promise<void>;

  // Receitas
  getReceitas(search?: string): Promise<Receita[]>;
  getReceita(id: string): Promise<Receita | undefined>;
  createReceita(receita: InsertReceita): Promise<Receita>;
  updateReceita(id: string, receita: Partial<InsertReceita>): Promise<Receita>;
  deleteReceita(id: string): Promise<void>;

  // Itens de receita
  getItensReceita(receitaId: string): Promise<(ItemReceita & { materiaPrima: MateriaPrima })[]>;
  createItemReceita(item: InsertItemReceita): Promise<ItemReceita>;
  deleteItemReceita(id: string): Promise<void>;

  // Produtos
  getProdutos(search?: string): Promise<Produto[]>;
  getProduto(id: string): Promise<Produto | undefined>;
  createProduto(produto: InsertProduto): Promise<Produto>;
  updateProduto(id: string, produto: Partial<InsertProduto>): Promise<Produto>;
  deleteProduto(id: string): Promise<void>;

  // Embalagens
  getEmbalagens(search?: string): Promise<Embalagem[]>;
  getEmbalagem(id: string): Promise<Embalagem | undefined>;
  createEmbalagem(embalagem: InsertEmbalagem): Promise<Embalagem>;
  updateEmbalagem(id: string, embalagem: Partial<InsertEmbalagem>): Promise<Embalagem>;
  deleteEmbalagem(id: string): Promise<void>;

  // Componentes do produto
  getComponentesProduto(produtoId: string): Promise<(ComponenteProduto & { receita?: Receita; embalagem?: Embalagem })[]>;
  createComponenteProduto(componente: InsertComponenteProduto): Promise<ComponenteProduto>;
  deleteComponenteProduto(id: string): Promise<void>;

  // Clientes
  getClientes(search?: string): Promise<Cliente[]>;
  getCliente(id: string): Promise<Cliente | undefined>;
  createCliente(cliente: InsertCliente): Promise<Cliente>;
  updateCliente(id: string, cliente: Partial<InsertCliente>): Promise<Cliente>;
  deleteCliente(id: string): Promise<void>;

  // Pedidos
  getPedidos(filters?: { dataInicio?: Date; dataFim?: Date; status?: string }): Promise<(Pedido & { cliente: Cliente })[]>;
  getPedido(id: string): Promise<(Pedido & { cliente: Cliente; itens: (ItemPedido & { produto: Produto })[] }) | undefined>;
  createPedido(pedido: InsertPedido): Promise<Pedido>;
  updatePedido(id: string, pedido: Partial<InsertPedido>): Promise<Pedido>;
  deletePedido(id: string): Promise<void>;

  // Itens do pedido
  createItemPedido(item: InsertItemPedido): Promise<ItemPedido>;
  deleteItemPedido(id: string): Promise<void>;

  // Movimentos de estoque
  createMovimentoEstoque(movimento: Omit<MovimentoEstoque, 'id' | 'data'>): Promise<MovimentoEstoque>;
  getMovimentosEstoque(filters?: { tipo?: string; dataInicio?: Date; dataFim?: Date }): Promise<MovimentoEstoque[]>;

  // Configurações
  getConfigImpressoras(): Promise<ConfigImpressoras | undefined>;
  updateConfigImpressoras(config: InsertConfigImpressoras): Promise<ConfigImpressoras>;

  // Métodos de produção
  updateEstoqueMateriaPrima(id: string, novoEstoque: number): Promise<void>;
  updateEstoqueReceita(id: string, novoEstoque: number): Promise<void>;
  updateEstoqueProduto(id: string, novoEstoque: number): Promise<void>;
  updateEstoqueEmbalagem(id: string, novoEstoque: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(schema.users).values(user).returning();
    return result[0];
  }

  // Matérias-primas
  async getMateriasPrimas(search?: string): Promise<MateriaPrima[]> {
    let query = db.select().from(schema.materiasPrimas);
    
    if (search) {
      query = query.where(like(schema.materiasPrimas.nome, `%${search}%`));
    }
    
    return await query.orderBy(asc(schema.materiasPrimas.nome));
  }

  async getMateriaPrima(id: string): Promise<MateriaPrima | undefined> {
    const result = await db.select().from(schema.materiasPrimas).where(eq(schema.materiasPrimas.id, id));
    return result[0];
  }

  async createMateriaPrima(materiaPrima: InsertMateriaPrima): Promise<MateriaPrima> {
    const result = await db.insert(schema.materiasPrimas).values(materiaPrima).returning();
    return result[0];
  }

  async updateMateriaPrima(id: string, materiaPrima: Partial<InsertMateriaPrima>): Promise<MateriaPrima> {
    const result = await db
      .update(schema.materiasPrimas)
      .set({ ...materiaPrima, updatedAt: new Date() })
      .where(eq(schema.materiasPrimas.id, id))
      .returning();
    return result[0];
  }

  async deleteMateriaPrima(id: string): Promise<void> {
    await db.delete(schema.materiasPrimas).where(eq(schema.materiasPrimas.id, id));
  }

  async updateEstoqueMateriaPrima(id: string, novoEstoque: number): Promise<void> {
    await db
      .update(schema.materiasPrimas)
      .set({ estoqueAtual: novoEstoque.toString(), updatedAt: new Date() })
      .where(eq(schema.materiasPrimas.id, id));
  }

  // Receitas
  async getReceitas(search?: string): Promise<Receita[]> {
    let query = db.select().from(schema.receitas);
    
    if (search) {
      query = query.where(like(schema.receitas.nome, `%${search}%`));
    }
    
    return await query.orderBy(asc(schema.receitas.nome));
  }

  async getReceita(id: string): Promise<Receita | undefined> {
    const result = await db.select().from(schema.receitas).where(eq(schema.receitas.id, id));
    return result[0];
  }

  async createReceita(receita: InsertReceita): Promise<Receita> {
    const result = await db.insert(schema.receitas).values(receita).returning();
    return result[0];
  }

  async updateReceita(id: string, receita: Partial<InsertReceita>): Promise<Receita> {
    const result = await db
      .update(schema.receitas)
      .set({ ...receita, updatedAt: new Date() })
      .where(eq(schema.receitas.id, id))
      .returning();
    return result[0];
  }

  async deleteReceita(id: string): Promise<void> {
    await db.delete(schema.receitas).where(eq(schema.receitas.id, id));
  }

  async updateEstoqueReceita(id: string, novoEstoque: number): Promise<void> {
    await db
      .update(schema.receitas)
      .set({ estoqueAtual: novoEstoque.toString(), updatedAt: new Date() })
      .where(eq(schema.receitas.id, id));
  }

  // Itens de receita
  async getItensReceita(receitaId: string): Promise<(ItemReceita & { materiaPrima: MateriaPrima })[]> {
    const result = await db
      .select()
      .from(schema.itensReceita)
      .innerJoin(schema.materiasPrimas, eq(schema.itensReceita.materiaPrimaId, schema.materiasPrimas.id))
      .where(eq(schema.itensReceita.receitaId, receitaId));
    
    return result.map(row => ({
      ...row.itens_receita,
      materiaPrima: row.materias_primas
    }));
  }

  async createItemReceita(item: InsertItemReceita): Promise<ItemReceita> {
    const result = await db.insert(schema.itensReceita).values(item).returning();
    return result[0];
  }

  async deleteItemReceita(id: string): Promise<void> {
    await db.delete(schema.itensReceita).where(eq(schema.itensReceita.id, id));
  }

  // Produtos
  async getProdutos(search?: string): Promise<Produto[]> {
    let query = db.select().from(schema.produtos);
    
    if (search) {
      query = query.where(like(schema.produtos.nome, `%${search}%`));
    }
    
    return await query.orderBy(asc(schema.produtos.nome));
  }

  async getProduto(id: string): Promise<Produto | undefined> {
    const result = await db.select().from(schema.produtos).where(eq(schema.produtos.id, id));
    return result[0];
  }

  async createProduto(produto: InsertProduto): Promise<Produto> {
    const result = await db.insert(schema.produtos).values(produto).returning();
    return result[0];
  }

  async updateProduto(id: string, produto: Partial<InsertProduto>): Promise<Produto> {
    const result = await db
      .update(schema.produtos)
      .set({ ...produto, updatedAt: new Date() })
      .where(eq(schema.produtos.id, id))
      .returning();
    return result[0];
  }

  async deleteProduto(id: string): Promise<void> {
    await db.delete(schema.produtos).where(eq(schema.produtos.id, id));
  }

  async updateEstoqueProduto(id: string, novoEstoque: number): Promise<void> {
    await db
      .update(schema.produtos)
      .set({ estoqueAtual: novoEstoque.toString(), updatedAt: new Date() })
      .where(eq(schema.produtos.id, id));
  }

  // Embalagens
  async getEmbalagens(search?: string): Promise<Embalagem[]> {
    let query = db.select().from(schema.embalagens);
    
    if (search) {
      query = query.where(like(schema.embalagens.nome, `%${search}%`));
    }
    
    return await query.orderBy(asc(schema.embalagens.nome));
  }

  async getEmbalagem(id: string): Promise<Embalagem | undefined> {
    const result = await db.select().from(schema.embalagens).where(eq(schema.embalagens.id, id));
    return result[0];
  }

  async createEmbalagem(embalagem: InsertEmbalagem): Promise<Embalagem> {
    const result = await db.insert(schema.embalagens).values(embalagem).returning();
    return result[0];
  }

  async updateEmbalagem(id: string, embalagem: Partial<InsertEmbalagem>): Promise<Embalagem> {
    const result = await db
      .update(schema.embalagens)
      .set({ ...embalagem, updatedAt: new Date() })
      .where(eq(schema.embalagens.id, id))
      .returning();
    return result[0];
  }

  async deleteEmbalagem(id: string): Promise<void> {
    await db.delete(schema.embalagens).where(eq(schema.embalagens.id, id));
  }

  async updateEstoqueEmbalagem(id: string, novoEstoque: number): Promise<void> {
    await db
      .update(schema.embalagens)
      .set({ estoqueAtual: novoEstoque.toString(), updatedAt: new Date() })
      .where(eq(schema.embalagens.id, id));
  }

  // Componentes do produto
  async getComponentesProduto(produtoId: string): Promise<(ComponenteProduto & { receita?: Receita; embalagem?: Embalagem })[]> {
    const result = await db
      .select()
      .from(schema.componentesProduto)
      .leftJoin(schema.receitas, eq(schema.componentesProduto.receitaId, schema.receitas.id))
      .leftJoin(schema.embalagens, eq(schema.componentesProduto.embalagemId, schema.embalagens.id))
      .where(eq(schema.componentesProduto.produtoId, produtoId));
    
    return result.map(row => ({
      ...row.componentes_produto,
      receita: row.receitas || undefined,
      embalagem: row.embalagens || undefined
    }));
  }

  async createComponenteProduto(componente: InsertComponenteProduto): Promise<ComponenteProduto> {
    const result = await db.insert(schema.componentesProduto).values(componente).returning();
    return result[0];
  }

  async deleteComponenteProduto(id: string): Promise<void> {
    await db.delete(schema.componentesProduto).where(eq(schema.componentesProduto.id, id));
  }

  // Clientes
  async getClientes(search?: string): Promise<Cliente[]> {
    let query = db.select().from(schema.clientes);
    
    if (search) {
      query = query.where(like(schema.clientes.nome, `%${search}%`));
    }
    
    return await query.orderBy(asc(schema.clientes.nome));
  }

  async getCliente(id: string): Promise<Cliente | undefined> {
    const result = await db.select().from(schema.clientes).where(eq(schema.clientes.id, id));
    return result[0];
  }

  async createCliente(cliente: InsertCliente): Promise<Cliente> {
    const result = await db.insert(schema.clientes).values(cliente).returning();
    return result[0];
  }

  async updateCliente(id: string, cliente: Partial<InsertCliente>): Promise<Cliente> {
    const result = await db
      .update(schema.clientes)
      .set({ ...cliente, updatedAt: new Date() })
      .where(eq(schema.clientes.id, id))
      .returning();
    return result[0];
  }

  async deleteCliente(id: string): Promise<void> {
    await db.delete(schema.clientes).where(eq(schema.clientes.id, id));
  }

  // Pedidos
  async getPedidos(filters?: { dataInicio?: Date; dataFim?: Date; status?: string }): Promise<(Pedido & { cliente: Cliente })[]> {
    let query = db
      .select()
      .from(schema.pedidos)
      .innerJoin(schema.clientes, eq(schema.pedidos.clienteId, schema.clientes.id));
    
    if (filters?.dataInicio && filters?.dataFim) {
      query = query.where(
        and(
          gte(schema.pedidos.dataEntrega, filters.dataInicio),
          lte(schema.pedidos.dataEntrega, filters.dataFim)
        )
      );
    }
    
    if (filters?.status) {
      query = query.where(eq(schema.pedidos.status, filters.status as any));
    }
    
    const result = await query.orderBy(desc(schema.pedidos.dataEntrega));
    
    return result.map(row => ({
      ...row.pedidos,
      cliente: row.clientes
    }));
  }

  async getPedido(id: string): Promise<(Pedido & { cliente: Cliente; itens: (ItemPedido & { produto: Produto })[] }) | undefined> {
    const pedidoResult = await db
      .select()
      .from(schema.pedidos)
      .innerJoin(schema.clientes, eq(schema.pedidos.clienteId, schema.clientes.id))
      .where(eq(schema.pedidos.id, id));
    
    if (!pedidoResult[0]) return undefined;
    
    const itensResult = await db
      .select()
      .from(schema.itensPedido)
      .innerJoin(schema.produtos, eq(schema.itensPedido.produtoId, schema.produtos.id))
      .where(eq(schema.itensPedido.pedidoId, id));
    
    const pedido = pedidoResult[0];
    const itens = itensResult.map(row => ({
      ...row.itens_pedido,
      produto: row.produtos
    }));
    
    return {
      ...pedido.pedidos,
      cliente: pedido.clientes,
      itens
    };
  }

  async createPedido(pedido: InsertPedido): Promise<Pedido> {
    const result = await db.insert(schema.pedidos).values(pedido).returning();
    return result[0];
  }

  async updatePedido(id: string, pedido: Partial<InsertPedido>): Promise<Pedido> {
    const result = await db
      .update(schema.pedidos)
      .set({ ...pedido, updatedAt: new Date() })
      .where(eq(schema.pedidos.id, id))
      .returning();
    return result[0];
  }

  async deletePedido(id: string): Promise<void> {
    await db.delete(schema.pedidos).where(eq(schema.pedidos.id, id));
  }

  // Itens do pedido
  async createItemPedido(item: InsertItemPedido): Promise<ItemPedido> {
    const result = await db.insert(schema.itensPedido).values(item).returning();
    return result[0];
  }

  async deleteItemPedido(id: string): Promise<void> {
    await db.delete(schema.itensPedido).where(eq(schema.itensPedido.id, id));
  }

  // Movimentos de estoque
  async createMovimentoEstoque(movimento: Omit<MovimentoEstoque, 'id' | 'data'>): Promise<MovimentoEstoque> {
    const result = await db.insert(schema.movimentosEstoque).values(movimento).returning();
    return result[0];
  }

  async getMovimentosEstoque(filters?: { tipo?: string; dataInicio?: Date; dataFim?: Date }): Promise<MovimentoEstoque[]> {
    let query = db.select().from(schema.movimentosEstoque);
    
    const conditions = [];
    
    if (filters?.tipo) {
      conditions.push(eq(schema.movimentosEstoque.tipo, filters.tipo as any));
    }
    
    if (filters?.dataInicio && filters?.dataFim) {
      conditions.push(
        and(
          gte(schema.movimentosEstoque.data, filters.dataInicio),
          lte(schema.movimentosEstoque.data, filters.dataFim)
        )
      );
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(schema.movimentosEstoque.data));
  }

  // Configurações
  async getConfigImpressoras(): Promise<ConfigImpressoras | undefined> {
    const result = await db.select().from(schema.configImpressoras).limit(1);
    return result[0];
  }

  async updateConfigImpressoras(config: InsertConfigImpressoras): Promise<ConfigImpressoras> {
    // Primeiro tenta fazer update
    const existing = await this.getConfigImpressoras();
    
    if (existing) {
      const result = await db
        .update(schema.configImpressoras)
        .set({ ...config, updatedAt: new Date() })
        .where(eq(schema.configImpressoras.id, existing.id))
        .returning();
      return result[0];
    } else {
      // Se não existe, cria novo
      const result = await db.insert(schema.configImpressoras).values(config).returning();
      return result[0];
    }
  }
}

export const storage = new DatabaseStorage();
