import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { produtoSchema, componenteProdutoSchema, producaoProdutoSchema } from "@/lib/validations";
import type { Produto, Receita, Embalagem, ComponenteProduto } from "@shared/schema";
import { Plus, Edit, Trash2, Cookie, Factory, Eye } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function Produtos() {
  const [editingItem, setEditingItem] = useState<Produto | null>(null);
  const [viewingItem, setViewingItem] = useState<Produto | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isProducaoDialogOpen, setIsProducaoDialogOpen] = useState(false);
  const [isComponenteDialogOpen, setIsComponenteDialogOpen] = useState(false);
  const [selectedProduto, setSelectedProduto] = useState<Produto | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: produtos, isLoading } = useQuery<Produto[]>({
    queryKey: ['/api/produtos']
  });

  const { data: receitas } = useQuery<Receita[]>({
    queryKey: ['/api/receitas']
  });

  const { data: embalagens } = useQuery<Embalagem[]>({
    queryKey: ['/api/embalagens']
  });

  const { data: componentesProduto } = useQuery<(ComponenteProduto & { receita?: Receita; embalagem?: Embalagem })[]>({
    queryKey: ['/api/produtos', viewingItem?.id, 'componentes'],
    enabled: !!viewingItem?.id
  });

  const form = useForm({
    resolver: zodResolver(produtoSchema),
    defaultValues: {
      nome: "",
      descricao: "",
      precoVenda: "0",
      unidade: ""
    }
  });

  const componenteForm = useForm({
    resolver: zodResolver(componenteProdutoSchema),
    defaultValues: {
      receitaId: "",
      embalagemId: "",
      quantidade: ""
    }
  });

  const producaoForm = useForm({
    resolver: zodResolver(producaoProdutoSchema),
    defaultValues: {
      produtoId: "",
      quantidadeProduzir: ""
    }
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/produtos', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Produto criado com sucesso"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest('PUT', `/api/produtos/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos'] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({
        title: "Sucesso", 
        description: "Produto atualizado com sucesso"
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/produtos/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos'] });
      toast({
        title: "Sucesso",
        description: "Produto removido com sucesso"
      });
    }
  });

  const addComponenteMutation = useMutation({
    mutationFn: ({ produtoId, data }: { produtoId: string; data: any }) =>
      apiRequest('POST', `/api/produtos/${produtoId}/componentes`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos', viewingItem?.id, 'componentes'] });
      setIsComponenteDialogOpen(false);
      componenteForm.reset();
      toast({
        title: "Sucesso",
        description: "Componente adicionado ao produto"
      });
    }
  });

  const removeComponenteMutation = useMutation({
    mutationFn: (componenteId: string) => apiRequest('DELETE', `/api/produtos/componentes/${componenteId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos', viewingItem?.id, 'componentes'] });
      toast({
        title: "Sucesso",
        description: "Componente removido do produto"
      });
    }
  });

  const producaoMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/producao/produto', {
      produtoId: data.produtoId,
      quantidadeProduzir: parseFloat(data.quantidadeProduzir)
    }),
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos'] });
      setIsProducaoDialogOpen(false);
      producaoForm.reset();
      toast({
        title: "Sucesso",
        description: response.message || "Produção realizada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro na produção",
        description: error.message
      });
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data });
    } else {
      createMutation.mutate(data);
    }
  });

  const handleEdit = (item: Produto) => {
    setEditingItem(item);
    form.reset({
      nome: item.nome,
      descricao: item.descricao || "",
      precoVenda: item.precoVenda,
      unidade: item.unidade || ""
    });
    setIsDialogOpen(true);
  };

  const handleView = (item: Produto) => {
    setViewingItem(item);
    setIsViewDialogOpen(true);
  };

  const handleProducao = (item: Produto) => {
    setSelectedProduto(item);
    producaoForm.setValue("produtoId", item.id);
    setIsProducaoDialogOpen(true);
  };

  const handleAddComponente = componenteForm.handleSubmit((data) => {
    if (viewingItem) {
      addComponenteMutation.mutate({ produtoId: viewingItem.id, data });
    }
  });

  const handleProducaoSubmit = producaoForm.handleSubmit((data) => {
    producaoMutation.mutate(data);
  });

  const columns: ColumnDef<Produto>[] = [
    {
      accessorKey: "nome",
      header: "Nome"
    },
    {
      accessorKey: "precoVenda",
      header: "Preço",
      cell: ({ row }) => `R$ ${parseFloat(row.getValue("precoVenda")).toFixed(2)}`
    },
    {
      accessorKey: "unidade",
      header: "Unidade",
      cell: ({ row }) => row.getValue("unidade") || "-"
    },
    {
      accessorKey: "estoqueAtual",
      header: "Estoque",
      cell: ({ row }) => {
        const estoque = parseFloat(row.getValue("estoqueAtual"));
        const unidade = row.original.unidade || "un";
        return `${estoque} ${unidade}`;
      }
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleView(row.original)}
            data-testid={`view-${row.original.id}`}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleEdit(row.original)}
            data-testid={`edit-${row.original.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleProducao(row.original)}
            data-testid={`produce-${row.original.id}`}
          >
            <Factory className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <Topbar 
        title="Produtos" 
        description="Gestão de produtos finais"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Cookie className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Produtos</p>
                  <p className="text-2xl font-bold" data-testid="total-produtos">
                    {produtos?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Factory className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Em Estoque</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="produtos-estoque">
                    {produtos?.filter(p => parseFloat(p.estoqueAtual) > 0).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      setEditingItem(null);
                      form.reset();
                    }}
                    data-testid="button-novo-produto"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Novo Produto
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingItem ? "Editar Produto" : "Novo Produto"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="nome"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Ex: Brigadeiro de Cacau de Colher"
                                data-testid="input-nome"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="descricao"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Descrição</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Descrição do produto..."
                                data-testid="input-descricao"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="precoVenda"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preço de Venda (R$)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.01"
                                  placeholder="0.00"
                                  data-testid="input-preco-venda"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="unidade"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Unidade</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-unidade">
                                    <SelectValue placeholder="Selecione" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="unidade">Unidade</SelectItem>
                                  <SelectItem value="fatia">Fatia</SelectItem>
                                  <SelectItem value="pote">Pote</SelectItem>
                                  <SelectItem value="caixa">Caixa</SelectItem>
                                  <SelectItem value="kg">Quilogramas (kg)</SelectItem>
                                  <SelectItem value="g">Gramas (g)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="flex justify-end gap-4 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsDialogOpen(false)}
                          data-testid="button-cancelar"
                        >
                          Cancelar
                        </Button>
                        <Button
                          type="submit"
                          disabled={createMutation.isPending || updateMutation.isPending}
                          data-testid="button-salvar"
                        >
                          {createMutation.isPending || updateMutation.isPending 
                            ? "Salvando..." 
                            : "Salvar"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={produtos || []}
                searchPlaceholder="Buscar produtos..."
              />
            )}
          </CardContent>
        </Card>

        {/* View Product Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Produto: {viewingItem?.nome}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold">Informações</h4>
                  <p><strong>Preço:</strong> R$ {parseFloat(viewingItem?.precoVenda || "0").toFixed(2)}</p>
                  <p><strong>Unidade:</strong> {viewingItem?.unidade || "-"}</p>
                  <p><strong>Estoque:</strong> {viewingItem?.estoqueAtual}</p>
                  {viewingItem?.descricao && (
                    <p><strong>Descrição:</strong> {viewingItem.descricao}</p>
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">Componentes</h4>
                  <Dialog open={isComponenteDialogOpen} onOpenChange={setIsComponenteDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" data-testid="button-add-componente">
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Componente
                      </Button>
                    </DialogTrigger>
                    
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Adicionar Componente</DialogTitle>
                      </DialogHeader>
                      
                      <Form {...componenteForm}>
                        <form onSubmit={handleAddComponente} className="space-y-4">
                          <FormField
                            control={componenteForm.control}
                            name="receitaId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Receita</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value || ""}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-receita">
                                      <SelectValue placeholder="Selecione uma receita" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="">Nenhuma receita</SelectItem>
                                    {receitas?.map(receita => (
                                      <SelectItem key={receita.id} value={receita.id}>
                                        {receita.nome} ({receita.unidadeSaida})
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={componenteForm.control}
                            name="embalagemId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Embalagem</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value || ""}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-embalagem">
                                      <SelectValue placeholder="Selecione uma embalagem" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="">Nenhuma embalagem</SelectItem>
                                    {embalagens?.map(embalagem => (
                                      <SelectItem key={embalagem.id} value={embalagem.id}>
                                        {embalagem.nome} ({embalagem.unidade})
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={componenteForm.control}
                            name="quantidade"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Quantidade *</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number"
                                    step="0.001"
                                    placeholder="0"
                                    data-testid="input-quantidade-componente"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <div className="flex justify-end gap-4">
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => setIsComponenteDialogOpen(false)}
                            >
                              Cancelar
                            </Button>
                            <Button
                              type="submit"
                              disabled={addComponenteMutation.isPending}
                            >
                              {addComponenteMutation.isPending ? "Adicionando..." : "Adicionar"}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="space-y-2">
                  {componentesProduto?.map(componente => (
                    <div 
                      key={componente.id} 
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <span className="font-medium">
                          {componente.receita?.nome || componente.embalagem?.nome}
                        </span>
                        <span className="text-muted-foreground ml-2">
                          {parseFloat(componente.quantidade)} {componente.receita?.unidadeSaida || componente.embalagem?.unidade}
                        </span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeComponenteMutation.mutate(componente.id)}
                        disabled={removeComponenteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )) || <p className="text-muted-foreground">Nenhum componente adicionado</p>}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Production Dialog */}
        <Dialog open={isProducaoDialogOpen} onOpenChange={setIsProducaoDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Produzir Produto: {selectedProduto?.nome}</DialogTitle>
            </DialogHeader>
            
            <Form {...producaoForm}>
              <form onSubmit={handleProducaoSubmit} className="space-y-4">
                <FormField
                  control={producaoForm.control}
                  name="quantidadeProduzir"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantidade a Produzir</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          step="0.001"
                          placeholder="0"
                          data-testid="input-quantidade-produzir-produto"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="text-sm text-muted-foreground">
                  <p><strong>Preço:</strong> R$ {parseFloat(selectedProduto?.precoVenda || "0").toFixed(2)}</p>
                  <p><strong>Estoque atual:</strong> {selectedProduto?.estoqueAtual} {selectedProduto?.unidade}</p>
                </div>

                <div className="flex justify-end gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsProducaoDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={producaoMutation.isPending}
                    data-testid="button-confirmar-producao-produto"
                  >
                    {producaoMutation.isPending ? "Produzindo..." : "Confirmar Produção"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
