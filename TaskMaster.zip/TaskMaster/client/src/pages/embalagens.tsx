import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { embalagemSchema } from "@/lib/validations";
import type { Embalagem } from "@shared/schema";
import { Plus, Edit, Trash2, Box } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function Embalagens() {
  const [editingItem, setEditingItem] = useState<Embalagem | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: embalagens, isLoading } = useQuery<Embalagem[]>({
    queryKey: ['/api/embalagens']
  });

  const form = useForm({
    resolver: zodResolver(embalagemSchema),
    defaultValues: {
      nome: "",
      tipo: "",
      unidade: "",
      estoqueAtual: "0",
      custoUnitario: "0"
    }
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/embalagens', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/embalagens'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Embalagem criada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest('PUT', `/api/embalagens/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/embalagens'] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({
        title: "Sucesso", 
        description: "Embalagem atualizada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/embalagens/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/embalagens'] });
      toast({
        title: "Sucesso",
        description: "Embalagem removida com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro", 
        description: error.message
      });
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data });
    } else {
      createMutation.mutate(data);
    }
  });

  const handleEdit = (item: Embalagem) => {
    setEditingItem(item);
    form.reset({
      nome: item.nome,
      tipo: item.tipo || "",
      unidade: item.unidade || "",
      estoqueAtual: item.estoqueAtual,
      custoUnitario: item.custoUnitario
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta embalagem?')) {
      deleteMutation.mutate(id);
    }
  };

  const columns: ColumnDef<Embalagem>[] = [
    {
      accessorKey: "nome",
      header: "Nome"
    },
    {
      accessorKey: "tipo", 
      header: "Tipo",
      cell: ({ row }) => row.getValue("tipo") || "-"
    },
    {
      accessorKey: "estoqueAtual",
      header: "Estoque Atual",
      cell: ({ row }) => {
        const estoque = parseFloat(row.getValue("estoqueAtual"));
        const unidade = row.original.unidade || "un";
        return `${estoque} ${unidade}`;
      }
    },
    {
      accessorKey: "custoUnitario",
      header: "Custo Unit.",
      cell: ({ row }) => `R$ ${parseFloat(row.getValue("custoUnitario")).toFixed(2)}`
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleEdit(row.original)}
            data-testid={`edit-${row.original.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleDelete(row.original.id)}
            data-testid={`delete-${row.original.id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <Topbar 
        title="Embalagens" 
        description="Gestão de embalagens e acessórios"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Box className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Embalagens</p>
                  <p className="text-2xl font-bold" data-testid="total-embalagens">
                    {embalagens?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Box className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Em Estoque</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="embalagens-estoque">
                    {embalagens?.filter(e => parseFloat(e.estoqueAtual) > 0).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      setEditingItem(null);
                      form.reset();
                    }}
                    data-testid="button-nova-embalagem"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Embalagem
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingItem ? "Editar Embalagem" : "Nova Embalagem"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="nome"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nome *</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Ex: Caixa P"
                                  data-testid="input-nome"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="tipo"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Tipo</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-tipo">
                                    <SelectValue placeholder="Selecione" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="caixa">Caixa</SelectItem>
                                  <SelectItem value="sacola">Sacola</SelectItem>
                                  <SelectItem value="pote">Pote</SelectItem>
                                  <SelectItem value="tag">Tag</SelectItem>
                                  <SelectItem value="laco">Laço</SelectItem>
                                  <SelectItem value="papel">Papel</SelectItem>
                                  <SelectItem value="fita">Fita</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="unidade"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Unidade</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-unidade">
                                    <SelectValue placeholder="Selecione" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="unidade">Unidades (un)</SelectItem>
                                  <SelectItem value="metro">Metros (m)</SelectItem>
                                  <SelectItem value="centimetro">Centímetros (cm)</SelectItem>
                                  <SelectItem value="pacote">Pacotes</SelectItem>
                                  <SelectItem value="rolo">Rolos</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="estoqueAtual"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estoque Atual</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.001"
                                  placeholder="0"
                                  data-testid="input-estoque-atual"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="custoUnitario"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Custo Unitário (R$)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.01"
                                  placeholder="0.00"
                                  data-testid="input-custo-unitario"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="flex justify-end gap-4 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsDialogOpen(false)}
                          data-testid="button-cancelar"
                        >
                          Cancelar
                        </Button>
                        <Button
                          type="submit"
                          disabled={createMutation.isPending || updateMutation.isPending}
                          data-testid="button-salvar"
                        >
                          {createMutation.isPending || updateMutation.isPending 
                            ? "Salvando..." 
                            : "Salvar"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={embalagens || []}
                searchPlaceholder="Buscar embalagens..."
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
