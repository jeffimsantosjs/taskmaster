import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { materiaPrimaSchema } from "@/lib/validations";
import type { MateriaPrima } from "@shared/schema";
import { Plus, Edit, Trash2, Package, AlertTriangle } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function MateriasPrimas() {
  const [editingItem, setEditingItem] = useState<MateriaPrima | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: materiasPrimas, isLoading } = useQuery<MateriaPrima[]>({
    queryKey: ['/api/materias-primas']
  });

  const form = useForm({
    resolver: zodResolver(materiaPrimaSchema),
    defaultValues: {
      nome: "",
      categoria: "",
      unidade: "",
      estoqueAtual: "0",
      estoqueMinimo: "0", 
      custoUnitario: "0",
      fornecedor: "",
      observacoes: ""
    }
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/materias-primas', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/materias-primas'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Matéria-prima criada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest('PUT', `/api/materias-primas/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/materias-primas'] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({
        title: "Sucesso", 
        description: "Matéria-prima atualizada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/materias-primas/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/materias-primas'] });
      toast({
        title: "Sucesso",
        description: "Matéria-prima removida com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro", 
        description: error.message
      });
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data });
    } else {
      createMutation.mutate(data);
    }
  });

  const handleEdit = (item: MateriaPrima) => {
    setEditingItem(item);
    form.reset({
      nome: item.nome,
      categoria: item.categoria || "",
      unidade: item.unidade,
      estoqueAtual: item.estoqueAtual,
      estoqueMinimo: item.estoqueMinimo,
      custoUnitario: item.custoUnitario,
      fornecedor: item.fornecedor || "",
      observacoes: item.observacoes || ""
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta matéria-prima?')) {
      deleteMutation.mutate(id);
    }
  };

  const columns: ColumnDef<MateriaPrima>[] = [
    {
      accessorKey: "nome",
      header: "Nome"
    },
    {
      accessorKey: "categoria", 
      header: "Categoria",
      cell: ({ row }) => row.getValue("categoria") || "-"
    },
    {
      accessorKey: "estoqueAtual",
      header: "Estoque Atual",
      cell: ({ row }) => {
        const estoque = parseFloat(row.getValue("estoqueAtual"));
        const minimo = parseFloat(row.original.estoqueMinimo);
        const unidade = row.original.unidade;
        
        return (
          <div className="flex items-center gap-2">
            <span>{estoque} {unidade}</span>
            {estoque <= minimo && (
              <AlertTriangle className="h-4 w-4 text-red-500" />
            )}
          </div>
        );
      }
    },
    {
      accessorKey: "custoUnitario",
      header: "Custo Unit.",
      cell: ({ row }) => `R$ ${parseFloat(row.getValue("custoUnitario")).toFixed(2)}`
    },
    {
      accessorKey: "fornecedor",
      header: "Fornecedor",
      cell: ({ row }) => row.getValue("fornecedor") || "-"
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleEdit(row.original)}
            data-testid={`edit-${row.original.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleDelete(row.original.id)}
            data-testid={`delete-${row.original.id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  const lowStockCount = materiasPrimas?.filter(mp => 
    parseFloat(mp.estoqueAtual) <= parseFloat(mp.estoqueMinimo)
  ).length || 0;

  return (
    <div>
      <Topbar 
        title="Matérias-Primas" 
        description="Gestão de insumos para produção"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Itens</p>
                  <p className="text-2xl font-bold" data-testid="total-items">
                    {materiasPrimas?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Estoque Baixo</p>
                  <p className="text-2xl font-bold text-red-600" data-testid="low-stock-count">
                    {lowStockCount}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      setEditingItem(null);
                      form.reset();
                    }}
                    data-testid="button-nova-materia-prima"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Matéria-Prima
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingItem ? "Editar Matéria-Prima" : "Nova Matéria-Prima"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="nome"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nome *</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Ex: Farinha de Trigo"
                                  data-testid="input-nome"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="categoria"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Categoria</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Ex: Farináceos"
                                  data-testid="input-categoria"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="unidade"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Unidade *</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-unidade">
                                    <SelectValue placeholder="Selecione" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="g">Gramas (g)</SelectItem>
                                  <SelectItem value="kg">Quilogramas (kg)</SelectItem>
                                  <SelectItem value="ml">Mililitros (ml)</SelectItem>
                                  <SelectItem value="L">Litros (L)</SelectItem>
                                  <SelectItem value="un">Unidades (un)</SelectItem>
                                  <SelectItem value="lata">Latas</SelectItem>
                                  <SelectItem value="duzia">Dúzias</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="estoqueAtual"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estoque Atual</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.001"
                                  placeholder="0"
                                  data-testid="input-estoque-atual"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="estoqueMinimo"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estoque Mínimo</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.001"
                                  placeholder="0"
                                  data-testid="input-estoque-minimo"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="custoUnitario"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Custo Unitário (R$)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number"
                                  step="0.01"
                                  placeholder="0.00"
                                  data-testid="input-custo-unitario"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="fornecedor"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Fornecedor</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Ex: Fornecedor ABC"
                                  data-testid="input-fornecedor"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="observacoes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Observações</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Observações adicionais..."
                                data-testid="input-observacoes"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end gap-4 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsDialogOpen(false)}
                          data-testid="button-cancelar"
                        >
                          Cancelar
                        </Button>
                        <Button
                          type="submit"
                          disabled={createMutation.isPending || updateMutation.isPending}
                          data-testid="button-salvar"
                        >
                          {createMutation.isPending || updateMutation.isPending 
                            ? "Salvando..." 
                            : "Salvar"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={materiasPrimas || []}
                searchPlaceholder="Buscar matérias-primas..."
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
