import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { clienteSchema } from "@/lib/validations";
import { formatDate } from "@/lib/utils";
import type { Cliente } from "@shared/schema";
import { Plus, Edit, Trash2, Users, Calendar, Phone, Mail } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function Clientes() {
  const [editingItem, setEditingItem] = useState<Cliente | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: clientes, isLoading } = useQuery<Cliente[]>({
    queryKey: ['/api/clientes']
  });

  const form = useForm({
    resolver: zodResolver(clienteSchema),
    defaultValues: {
      nome: "",
      telefone: "",
      email: "",
      aniversario: undefined
    }
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/clientes', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clientes'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Cliente criado com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest('PUT', `/api/clientes/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clientes'] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({
        title: "Sucesso", 
        description: "Cliente atualizado com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/clientes/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clientes'] });
      toast({
        title: "Sucesso",
        description: "Cliente removido com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro", 
        description: error.message
      });
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    // Converter data de aniversário se fornecida
    const formattedData = {
      ...data,
      aniversario: data.aniversario ? new Date(data.aniversario).toISOString() : undefined
    };

    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formattedData });
    } else {
      createMutation.mutate(formattedData);
    }
  });

  const handleEdit = (item: Cliente) => {
    setEditingItem(item);
    form.reset({
      nome: item.nome,
      telefone: item.telefone || "",
      email: item.email || "",
      aniversario: item.aniversario ? new Date(item.aniversario) : undefined
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este cliente?')) {
      deleteMutation.mutate(id);
    }
  };

  // Calcular aniversariantes do mês
  const getAniversariantesDoMes = () => {
    const currentMonth = new Date().getMonth();
    return clientes?.filter(cliente => {
      if (!cliente.aniversario) return false;
      return new Date(cliente.aniversario).getMonth() === currentMonth;
    }) || [];
  };

  const columns: ColumnDef<Cliente>[] = [
    {
      accessorKey: "nome",
      header: "Nome"
    },
    {
      accessorKey: "telefone",
      header: "Telefone",
      cell: ({ row }) => {
        const telefone = row.getValue("telefone") as string;
        return telefone || "-";
      }
    },
    {
      accessorKey: "email",
      header: "Email",
      cell: ({ row }) => {
        const email = row.getValue("email") as string;
        return email || "-";
      }
    },
    {
      accessorKey: "aniversario",
      header: "Aniversário",
      cell: ({ row }) => {
        const aniversario = row.getValue("aniversario");
        return aniversario ? formatDate(aniversario as string) : "-";
      }
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleEdit(row.original)}
            data-testid={`edit-${row.original.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleDelete(row.original.id)}
            data-testid={`delete-${row.original.id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  const aniversariantes = getAniversariantesDoMes();

  return (
    <div>
      <Topbar 
        title="Clientes" 
        description="Gestão de clientes e contatos"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Clientes</p>
                  <p className="text-2xl font-bold" data-testid="total-clientes">
                    {clientes?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Aniversariantes</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="aniversariantes-mes">
                    {aniversariantes.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Phone className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Com Telefone</p>
                  <p className="text-2xl font-bold text-purple-600" data-testid="clientes-telefone">
                    {clientes?.filter(c => c.telefone).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      setEditingItem(null);
                      form.reset();
                    }}
                    data-testid="button-novo-cliente"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Novo Cliente
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingItem ? "Editar Cliente" : "Novo Cliente"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="nome"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Nome completo do cliente"
                                data-testid="input-nome"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="telefone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Telefone</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="(11) 99999-9999"
                                  data-testid="input-telefone"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input 
                                  type="email"
                                  placeholder="cliente@email.com"
                                  data-testid="input-email"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="aniversario"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Data de Aniversário</FormLabel>
                            <FormControl>
                              <Input
                                type="date"
                                data-testid="input-aniversario"
                                {...field}
                                value={field.value instanceof Date ? 
                                  field.value.toISOString().split('T')[0] : 
                                  field.value || ""
                                }
                                onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : undefined)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end gap-4 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsDialogOpen(false)}
                          data-testid="button-cancelar"
                        >
                          Cancelar
                        </Button>
                        <Button
                          type="submit"
                          disabled={createMutation.isPending || updateMutation.isPending}
                          data-testid="button-salvar"
                        >
                          {createMutation.isPending || updateMutation.isPending 
                            ? "Salvando..." 
                            : "Salvar"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Aniversariantes do Mês */}
        {aniversariantes.length > 0 && (
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">
                Aniversariantes de {new Date().toLocaleDateString('pt-BR', { month: 'long' })}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {aniversariantes.map(cliente => (
                  <div 
                    key={cliente.id} 
                    className="p-3 bg-muted rounded-lg flex items-center gap-3"
                    data-testid={`aniversariante-${cliente.id}`}
                  >
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{cliente.nome}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(cliente.aniversario!)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={clientes || []}
                searchPlaceholder="Buscar clientes..."
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
