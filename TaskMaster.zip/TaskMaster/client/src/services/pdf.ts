export class PDFService {
  static generateLabel(data: {
    type: 'reception' | 'kitchen';
    pedidoId: string;
    cliente: string;
    telefone?: string;
    dataEntrega: string;
    observacoes?: string;
    total?: string;
    itens?: Array<{
      produto: string;
      quantidade: number;
      customizacoes?: any;
    }>;
  }): string {
    // Simula geração de PDF
    // Em um cenário real, usaria uma biblioteca como jsPDF
    
    const pdfContent = {
      title: data.type === 'reception' ? 'ETIQUETA RECEPÇÃO' : 'ETIQUETA COZINHA',
      ...data
    };
    
    // Simula download do PDF
    const blob = new Blob([JSON.stringify(pdfContent, null, 2)], { 
      type: 'application/json' 
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `etiqueta_${data.type}_${data.pedidoId}.json`;
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
    
    return url;
  }
  
  static downloadPDF(url: string, filename: string) {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
