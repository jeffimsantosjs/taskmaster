import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Topbar } from "@/components/layout/topbar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/utils";
import type { Produto } from "@shared/schema";
import { Plus, Minus, Trash2, ShoppingCart, Search } from "lucide-react";

interface CartItem {
  produto: Produto;
  quantidade: number;
}

export default function VendaRapida() {
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: produtos, isLoading } = useQuery<Produto[]>({
    queryKey: ['/api/produtos']
  });

  const vendaMutation = useMutation({
    mutationFn: (data: { produtoId: string; quantidade: number }) => 
      apiRequest('POST', '/api/venda-rapida', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/produtos'] });
      toast({
        title: "Sucesso",
        description: "Venda realizada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro na venda",
        description: error.message
      });
    }
  });

  const filteredProdutos = produtos?.filter(produto =>
    produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) &&
    parseFloat(produto.estoqueAtual) > 0
  ) || [];

  const addToCart = (produto: Produto) => {
    setCart(prev => {
      const existing = prev.find(item => item.produto.id === produto.id);
      if (existing) {
        return prev.map(item =>
          item.produto.id === produto.id
            ? { ...item, quantidade: item.quantidade + 1 }
            : item
        );
      }
      return [...prev, { produto, quantidade: 1 }];
    });
  };

  const updateQuantity = (produtoId: string, quantidade: number) => {
    if (quantidade <= 0) {
      setCart(prev => prev.filter(item => item.produto.id !== produtoId));
    } else {
      setCart(prev =>
        prev.map(item =>
          item.produto.id === produtoId
            ? { ...item, quantidade }
            : item
        )
      );
    }
  };

  const removeFromCart = (produtoId: string) => {
    setCart(prev => prev.filter(item => item.produto.id !== produtoId));
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => {
      return total + (parseFloat(item.produto.precoVenda) * item.quantidade);
    }, 0);
  };

  const handleFinalizarVenda = async () => {
    if (cart.length === 0) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Adicione produtos ao carrinho"
      });
      return;
    }

    // Processar cada item do carrinho
    for (const item of cart) {
      try {
        await vendaMutation.mutateAsync({
          produtoId: item.produto.id,
          quantidade: item.quantidade
        });
      } catch (error) {
        // Se algum item falhar, parar o processo
        return;
      }
    }

    // Limpar carrinho após venda bem-sucedida
    setCart([]);
    toast({
      title: "Sucesso",
      description: `Venda finalizada: ${formatCurrency(getCartTotal())}`
    });
  };

  const canFinalizeSale = cart.every(item => {
    const estoqueAtual = parseFloat(item.produto.estoqueAtual);
    return estoqueAtual >= item.quantidade;
  });

  return (
    <div>
      <Topbar 
        title="Venda Rápida" 
        description="Ponto de venda para transações imediatas"
        showQuickActions={false}
      />
      
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Products Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <Card>
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Buscar produtos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-produtos"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Products Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {isLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-4">
                      <div className="h-20 bg-muted rounded"></div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                filteredProdutos.map(produto => (
                  <Card 
                    key={produto.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => addToCart(produto)}
                    data-testid={`product-${produto.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="text-center space-y-2">
                        <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto">
                          <ShoppingCart className="h-6 w-6 text-accent" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{produto.nome}</p>
                          <p className="text-xs text-muted-foreground">
                            Estoque: {parseFloat(produto.estoqueAtual)} {produto.unidade}
                          </p>
                          <p className="text-sm font-bold text-primary">
                            {formatCurrency(parseFloat(produto.precoVenda))}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {filteredProdutos.length === 0 && !isLoading && (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">
                    {searchTerm ? "Nenhum produto encontrado" : "Nenhum produto disponível"}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Cart Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Carrinho ({cart.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {cart.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    Carrinho vazio
                  </p>
                ) : (
                  <>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {cart.map(item => (
                        <div 
                          key={item.produto.id} 
                          className="flex items-center justify-between p-3 bg-muted rounded-lg"
                          data-testid={`cart-item-${item.produto.id}`}
                        >
                          <div className="flex-1">
                            <p className="font-medium text-sm">{item.produto.nome}</p>
                            <p className="text-xs text-muted-foreground">
                              {formatCurrency(parseFloat(item.produto.precoVenda))} cada
                            </p>
                            {parseFloat(item.produto.estoqueAtual) < item.quantidade && (
                              <p className="text-xs text-red-600">
                                Estoque insuficiente!
                              </p>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.produto.id, item.quantidade - 1)}
                              data-testid={`decrease-${item.produto.id}`}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            
                            <span className="w-8 text-center text-sm font-medium">
                              {item.quantidade}
                            </span>
                            
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.produto.id, item.quantidade + 1)}
                              disabled={parseFloat(item.produto.estoqueAtual) <= item.quantidade}
                              data-testid={`increase-${item.produto.id}`}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFromCart(item.produto.id)}
                              data-testid={`remove-${item.produto.id}`}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-lg font-semibold">Total</span>
                        <span className="text-xl font-bold text-primary" data-testid="cart-total">
                          {formatCurrency(getCartTotal())}
                        </span>
                      </div>

                      <Button
                        onClick={handleFinalizarVenda}
                        disabled={!canFinalizeSale || vendaMutation.isPending || cart.length === 0}
                        className="w-full"
                        size="lg"
                        data-testid="button-finalizar-venda"
                      >
                        {vendaMutation.isPending ? (
                          "Processando..."
                        ) : !canFinalizeSale ? (
                          "Estoque Insuficiente"
                        ) : (
                          "Finalizar Venda"
                        )}
                      </Button>

                      {cart.length > 0 && (
                        <Button
                          variant="outline"
                          onClick={() => setCart([])}
                          className="w-full mt-2"
                          data-testid="button-limpar-carrinho"
                        >
                          Limpar Carrinho
                        </Button>
                      )}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Produtos Disponíveis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold" data-testid="produtos-disponiveis">
                  {produtos?.filter(p => parseFloat(p.estoqueAtual) > 0).length || 0}
                </p>
                <p className="text-sm text-muted-foreground">
                  de {produtos?.length || 0} produtos cadastrados
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
