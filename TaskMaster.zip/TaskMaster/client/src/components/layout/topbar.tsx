import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Plus, ScanBarcode } from "lucide-react";

interface TopbarProps {
  title: string;
  description?: string;
  showQuickActions?: boolean;
}

export function Topbar({ title, description, showQuickActions = true }: TopbarProps) {
  return (
    <header className="bg-card shadow-sm border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
            {title}
          </h2>
          {description && (
            <p className="text-sm text-muted-foreground" data-testid="page-description">
              {description}
            </p>
          )}
        </div>

        <div className="flex items-center gap-4">
          {/* Notifications */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative bg-muted hover:bg-muted/80"
            data-testid="button-notifications"
          >
            <Bell className="h-5 w-5" />
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center text-xs p-0"
            >
              3
            </Badge>
          </Button>

          {/* Quick Actions */}
          {showQuickActions && (
            <div className="flex gap-2">
              <Button 
                className="bg-primary hover:bg-primary/90"
                data-testid="button-novo-pedido"
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Pedido
              </Button>
              <Button 
                className="bg-accent hover:bg-accent/90"
                data-testid="button-venda-rapida"
              >
                <ScanBarcode className="h-4 w-4 mr-2" />
                Venda Rápida
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
