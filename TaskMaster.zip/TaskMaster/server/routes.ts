import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { productionService } from "./services/production";
import { labelService } from "./services/labels";
import bcrypt from "bcryptjs";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { 
  insertMateriaPrimaSchema, 
  insertReceitaSchema, 
  insertItemReceitaSchema,
  insertProdutoSchema,
  insertEmbalagemSchema,
  insertComponenteProdutoSchema,
  insertClienteSchema,
  insertPedidoSchema,
  insertItemPedidoSchema,
  insertConfigImpressorasSchema
} from "@shared/schema";
import { z } from "zod";
import MemoryStore from "memorystore";

const MemoryStoreSession = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "bakery-secret-key",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      cookie: {
        secure: false, // set to true in production with HTTPS
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
      },
    })
  );

  // Passport configuration
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false);
        }

        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
          return done(null, false);
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Auth middleware
  function requireAuth(req: any, res: any, next: any) {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Acesso não autorizado" });
  }

  // Auth routes
  app.post("/api/auth/login", passport.authenticate("local"), (req, res) => {
    res.json({ user: req.user });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (req.isAuthenticated()) {
      res.json({ user: req.user });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // Matérias-primas routes
  app.get("/api/materias-primas", requireAuth, async (req, res) => {
    try {
      const search = req.query.search as string;
      const materiasPrimas = await storage.getMateriasPrimas(search);
      res.json(materiasPrimas);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.get("/api/materias-primas/:id", requireAuth, async (req, res) => {
    try {
      const materiaPrima = await storage.getMateriaPrima(req.params.id);
      if (!materiaPrima) {
        return res.status(404).json({ message: "Matéria-prima não encontrada" });
      }
      res.json(materiaPrima);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/materias-primas", requireAuth, async (req, res) => {
    try {
      const data = insertMateriaPrimaSchema.parse(req.body);
      const materiaPrima = await storage.createMateriaPrima(data);
      res.status(201).json(materiaPrima);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/materias-primas/:id", requireAuth, async (req, res) => {
    try {
      const data = insertMateriaPrimaSchema.partial().parse(req.body);
      const materiaPrima = await storage.updateMateriaPrima(req.params.id, data);
      res.json(materiaPrima);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/materias-primas/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteMateriaPrima(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Receitas routes
  app.get("/api/receitas", requireAuth, async (req, res) => {
    try {
      const search = req.query.search as string;
      const receitas = await storage.getReceitas(search);
      res.json(receitas);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.get("/api/receitas/:id", requireAuth, async (req, res) => {
    try {
      const receita = await storage.getReceita(req.params.id);
      if (!receita) {
        return res.status(404).json({ message: "Receita não encontrada" });
      }
      res.json(receita);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/receitas", requireAuth, async (req, res) => {
    try {
      const data = insertReceitaSchema.parse(req.body);
      const receita = await storage.createReceita(data);
      res.status(201).json(receita);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/receitas/:id", requireAuth, async (req, res) => {
    try {
      const data = insertReceitaSchema.partial().parse(req.body);
      const receita = await storage.updateReceita(req.params.id, data);
      res.json(receita);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/receitas/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteReceita(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Itens de receita routes
  app.get("/api/receitas/:id/itens", requireAuth, async (req, res) => {
    try {
      const itens = await storage.getItensReceita(req.params.id);
      res.json(itens);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/receitas/:id/itens", requireAuth, async (req, res) => {
    try {
      const data = insertItemReceitaSchema.parse({
        ...req.body,
        receitaId: req.params.id
      });
      const item = await storage.createItemReceita(data);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/receitas/itens/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteItemReceita(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Produção de receitas
  app.post("/api/producao/receita", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        receitaId: z.string(),
        quantidadeProduzir: z.number().positive()
      });
      
      const { receitaId, quantidadeProduzir } = schema.parse(req.body);
      const result = await productionService.produzirReceita(receitaId, quantidadeProduzir);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Produtos routes
  app.get("/api/produtos", requireAuth, async (req, res) => {
    try {
      const search = req.query.search as string;
      const produtos = await storage.getProdutos(search);
      res.json(produtos);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.get("/api/produtos/:id", requireAuth, async (req, res) => {
    try {
      const produto = await storage.getProduto(req.params.id);
      if (!produto) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      res.json(produto);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/produtos", requireAuth, async (req, res) => {
    try {
      const data = insertProdutoSchema.parse(req.body);
      const produto = await storage.createProduto(data);
      res.status(201).json(produto);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/produtos/:id", requireAuth, async (req, res) => {
    try {
      const data = insertProdutoSchema.partial().parse(req.body);
      const produto = await storage.updateProduto(req.params.id, data);
      res.json(produto);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/produtos/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteProduto(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Componentes do produto
  app.get("/api/produtos/:id/componentes", requireAuth, async (req, res) => {
    try {
      const componentes = await storage.getComponentesProduto(req.params.id);
      res.json(componentes);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/produtos/:id/componentes", requireAuth, async (req, res) => {
    try {
      const data = insertComponenteProdutoSchema.parse({
        ...req.body,
        produtoId: req.params.id
      });
      const componente = await storage.createComponenteProduto(data);
      res.status(201).json(componente);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/produtos/componentes/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteComponenteProduto(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Produção de produtos
  app.post("/api/producao/produto", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        produtoId: z.string(),
        quantidadeProduzir: z.number().positive()
      });
      
      const { produtoId, quantidadeProduzir } = schema.parse(req.body);
      const result = await productionService.produzirProduto(produtoId, quantidadeProduzir);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Embalagens routes
  app.get("/api/embalagens", requireAuth, async (req, res) => {
    try {
      const search = req.query.search as string;
      const embalagens = await storage.getEmbalagens(search);
      res.json(embalagens);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/embalagens", requireAuth, async (req, res) => {
    try {
      const data = insertEmbalagemSchema.parse(req.body);
      const embalagem = await storage.createEmbalagem(data);
      res.status(201).json(embalagem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/embalagens/:id", requireAuth, async (req, res) => {
    try {
      const data = insertEmbalagemSchema.partial().parse(req.body);
      const embalagem = await storage.updateEmbalagem(req.params.id, data);
      res.json(embalagem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/embalagens/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteEmbalagem(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Clientes routes
  app.get("/api/clientes", requireAuth, async (req, res) => {
    try {
      const search = req.query.search as string;
      const clientes = await storage.getClientes(search);
      res.json(clientes);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/clientes", requireAuth, async (req, res) => {
    try {
      const data = insertClienteSchema.parse(req.body);
      const cliente = await storage.createCliente(data);
      res.status(201).json(cliente);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/clientes/:id", requireAuth, async (req, res) => {
    try {
      const data = insertClienteSchema.partial().parse(req.body);
      const cliente = await storage.updateCliente(req.params.id, data);
      res.json(cliente);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/clientes/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteCliente(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Pedidos routes
  app.get("/api/pedidos", requireAuth, async (req, res) => {
    try {
      const filters: any = {};
      
      if (req.query.dataInicio) {
        filters.dataInicio = new Date(req.query.dataInicio as string);
      }
      if (req.query.dataFim) {
        filters.dataFim = new Date(req.query.dataFim as string);
      }
      if (req.query.status) {
        filters.status = req.query.status as string;
      }
      
      const pedidos = await storage.getPedidos(filters);
      res.json(pedidos);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.get("/api/pedidos/:id", requireAuth, async (req, res) => {
    try {
      const pedido = await storage.getPedido(req.params.id);
      if (!pedido) {
        return res.status(404).json({ message: "Pedido não encontrado" });
      }
      res.json(pedido);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/pedidos", requireAuth, async (req, res) => {
    try {
      const data = insertPedidoSchema.parse(req.body);
      const pedido = await storage.createPedido(data);
      res.status(201).json(pedido);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/pedidos/:id", requireAuth, async (req, res) => {
    try {
      const data = insertPedidoSchema.partial().parse(req.body);
      const pedido = await storage.updatePedido(req.params.id, data);
      res.json(pedido);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/pedidos/:id", requireAuth, async (req, res) => {
    try {
      await storage.deletePedido(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Itens do pedido
  app.post("/api/pedidos/:id/itens", requireAuth, async (req, res) => {
    try {
      const data = insertItemPedidoSchema.parse({
        ...req.body,
        pedidoId: req.params.id
      });
      const item = await storage.createItemPedido(data);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Produzir pedidos em lote
  app.post("/api/pedidos/produzir", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        dataInicio: z.string().transform(str => new Date(str)),
        dataFim: z.string().transform(str => new Date(str))
      });
      
      const { dataInicio, dataFim } = schema.parse(req.body);
      const result = await productionService.produzirPedidos(dataInicio, dataFim);
      
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Venda rápida
  app.post("/api/venda-rapida", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        produtoId: z.string(),
        quantidade: z.number().positive()
      });
      
      const { produtoId, quantidade } = schema.parse(req.body);
      const result = await productionService.vendaRapida(produtoId, quantidade);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Etiquetas
  app.post("/api/etiquetas/:pedidoId", requireAuth, async (req, res) => {
    try {
      const result = await labelService.generateLabels(req.params.pedidoId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Configurações de impressoras
  app.get("/api/config/impressoras", requireAuth, async (req, res) => {
    try {
      const config = await storage.getConfigImpressoras();
      res.json(config || {});
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/config/impressoras", requireAuth, async (req, res) => {
    try {
      const data = insertConfigImpressorasSchema.parse(req.body);
      const config = await storage.updateConfigImpressoras(data);
      res.json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", requireAuth, async (req, res) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Pedidos hoje
      const pedidosHoje = await storage.getPedidos({
        dataInicio: today,
        dataFim: tomorrow
      });

      // Produtos com estoque baixo
      const materiasPrimas = await storage.getMateriasPrimas();
      const produtosBaixoEstoque = materiasPrimas.filter(mp => 
        parseFloat(mp.estoqueAtual) <= parseFloat(mp.estoqueMinimo)
      );

      // Pedidos em produção
      const pedidosProducao = await storage.getPedidos({
        status: 'EM_PRODUCAO'
      });

      const stats = {
        pedidosHoje: pedidosHoje.length,
        faturamentoHoje: pedidosHoje.reduce((sum, p) => sum + parseFloat(p.totalLiquido), 0),
        produtosBaixoEstoque: produtosBaixoEstoque.length,
        pedidosProducao: pedidosProducao.length
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
