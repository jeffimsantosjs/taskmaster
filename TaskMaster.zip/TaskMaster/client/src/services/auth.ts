import { create } from 'zustand';
import { apiRequest } from '@/lib/queryClient';

interface User {
  id: string;
  username: string;
  role: string;
}

interface AuthState {
  user: User | null;
  setUser: (user: User) => void;
  clearUser: () => void;
  login: (username: string, password: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  setUser: (user) => set({ user }),
  clearUser: () => set({ user: null }),
  
  login: async (username: string, password: string) => {
    try {
      const response = await apiRequest('POST', '/api/auth/login', {
        username,
        password
      });
      
      const data = await response.json();
      
      if (data.user) {
        set({ user: data.user });
        return { success: true };
      }
      
      return { success: false, message: 'Credenciais inválidas' };
    } catch (error: any) {
      return { success: false, message: error.message || 'Erro no login' };
    }
  },
  
  logout: async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
    } catch (error) {
      console.error('Erro no logout:', error);
    } finally {
      set({ user: null });
    }
  }
}));
