import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { producaoReceitaSchema } from "@/lib/validations";
import type { Receita, MateriaPrima, ItemReceita } from "@shared/schema";
import { Factory, ChefHat, AlertTriangle, CheckCircle } from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function ProducaoReceitas() {
  const [selectedReceita, setSelectedReceita] = useState<Receita | null>(null);
  const [isProducaoDialogOpen, setIsProducaoDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: receitas, isLoading } = useQuery<Receita[]>({
    queryKey: ['/api/receitas']
  });

  const { data: itensReceita } = useQuery<(ItemReceita & { materiaPrima: MateriaPrima })[]>({
    queryKey: ['/api/receitas', selectedReceita?.id, 'itens'],
    enabled: !!selectedReceita?.id
  });

  const form = useForm({
    resolver: zodResolver(producaoReceitaSchema),
    defaultValues: {
      receitaId: "",
      quantidadeProduzir: ""
    }
  });

  const producaoMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/producao/receita', {
      receitaId: data.receitaId,
      quantidadeProduzir: parseFloat(data.quantidadeProduzir)
    }),
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/receitas'] });
      queryClient.invalidateQueries({ queryKey: ['/api/materias-primas'] });
      setIsProducaoDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: response.message || "Produção realizada com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro na produção",
        description: error.message
      });
    }
  });

  const handleProducao = (receita: Receita) => {
    setSelectedReceita(receita);
    form.setValue("receitaId", receita.id);
    setIsProducaoDialogOpen(true);
  };

  const handleViewDetalhes = (receita: Receita) => {
    setSelectedReceita(receita);
    setIsViewDialogOpen(true);
  };

  const handleSubmit = form.handleSubmit((data) => {
    producaoMutation.mutate(data);
  });

  const checkIngredientesDisponiveis = (receita: Receita, quantidade: number) => {
    if (!itensReceita) return { disponivel: true, faltantes: [] };
    
    const faltantes = [];
    for (const item of itensReceita) {
      const qtdNecessaria = (parseFloat(item.quantidade) * quantidade) / parseFloat(receita.rendimentoPadrao);
      const estoqueAtual = parseFloat(item.materiaPrima.estoqueAtual);
      
      if (estoqueAtual < qtdNecessaria) {
        faltantes.push({
          nome: item.materiaPrima.nome,
          necessario: qtdNecessaria,
          disponivel: estoqueAtual,
          unidade: item.unidade
        });
      }
    }
    
    return { disponivel: faltantes.length === 0, faltantes };
  };

  const columns: ColumnDef<Receita>[] = [
    {
      accessorKey: "nome",
      header: "Nome"
    },
    {
      accessorKey: "unidadeSaida",
      header: "Unidade",
      cell: ({ row }) => row.getValue("unidadeSaida")
    },
    {
      accessorKey: "estoqueAtual",
      header: "Estoque Atual",
      cell: ({ row }) => {
        const estoque = parseFloat(row.getValue("estoqueAtual"));
        const unidade = row.original.unidadeSaida;
        return `${estoque} ${unidade}`;
      }
    },
    {
      accessorKey: "rendimentoPadrao",
      header: "Rendimento",
      cell: ({ row }) => {
        const rendimento = parseFloat(row.getValue("rendimentoPadrao"));
        const unidade = row.original.unidadeSaida;
        return `${rendimento} ${unidade}`;
      }
    },
    {
      id: "status",
      header: "Status",
      cell: ({ row }) => {
        const receita = row.original;
        const verificacao = checkIngredientesDisponiveis(receita, parseFloat(receita.rendimentoPadrao));
        
        return (
          <div className="flex items-center gap-2">
            {verificacao.disponivel ? (
              <>
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm text-green-600">Disponível</span>
              </>
            ) : (
              <>
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <span className="text-sm text-red-600">Falta insumo</span>
              </>
            )}
          </div>
        );
      }
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleViewDetalhes(row.original)}
            data-testid={`view-${row.original.id}`}
          >
            <ChefHat className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleProducao(row.original)}
            data-testid={`produce-${row.original.id}`}
          >
            <Factory className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  const receitasDisponiveis = receitas?.filter(receita => {
    const verificacao = checkIngredientesDisponiveis(receita, parseFloat(receita.rendimentoPadrao));
    return verificacao.disponivel;
  }) || [];

  return (
    <div>
      <Topbar 
        title="Produção de Receitas" 
        description="Controle de produção e ingredientes"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <ChefHat className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Receitas</p>
                  <p className="text-2xl font-bold" data-testid="total-receitas">
                    {receitas?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Disponíveis</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="receitas-disponiveis">
                    {receitasDisponiveis.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Falta Insumo</p>
                  <p className="text-2xl font-bold text-red-600" data-testid="receitas-falta-insumo">
                    {(receitas?.length || 0) - receitasDisponiveis.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Factory className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Em Estoque</p>
                  <p className="text-2xl font-bold text-yellow-600" data-testid="receitas-estoque">
                    {receitas?.filter(r => parseFloat(r.estoqueAtual) > 0).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Data Table */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-lg">Carregando...</div>
              </div>
            ) : (
              <DataTable
                columns={columns}
                data={receitas || []}
                searchPlaceholder="Buscar receitas..."
              />
            )}
          </CardContent>
        </Card>

        {/* View Details Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Detalhes: {selectedReceita?.nome}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold">Informações</h4>
                  <p><strong>Unidade:</strong> {selectedReceita?.unidadeSaida}</p>
                  <p><strong>Rendimento:</strong> {selectedReceita?.rendimentoPadrao}</p>
                  <p><strong>Estoque:</strong> {selectedReceita?.estoqueAtual}</p>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-4">Ingredientes Necessários</h4>
                <div className="space-y-2">
                  {itensReceita?.map(item => {
                    const qtdNecessaria = parseFloat(item.quantidade);
                    const estoqueAtual = parseFloat(item.materiaPrima.estoqueAtual);
                    const suficiente = estoqueAtual >= qtdNecessaria;
                    
                    return (
                      <div 
                        key={item.id} 
                        className={`flex items-center justify-between p-3 border rounded-lg ${
                          suficiente ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {suficiente ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-red-500" />
                          )}
                          <div>
                            <span className="font-medium">{item.materiaPrima.nome}</span>
                            <p className="text-sm text-muted-foreground">
                              Necessário: {qtdNecessaria} {item.unidade}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-medium ${suficiente ? 'text-green-600' : 'text-red-600'}`}>
                            Disponível: {estoqueAtual} {item.materiaPrima.unidade}
                          </p>
                        </div>
                      </div>
                    );
                  }) || <p className="text-muted-foreground">Nenhum ingrediente cadastrado</p>}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Production Dialog */}
        <Dialog open={isProducaoDialogOpen} onOpenChange={setIsProducaoDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Produzir Receita: {selectedReceita?.nome}</DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={handleSubmit} className="space-y-4">
                <FormField
                  control={form.control}
                  name="quantidadeProduzir"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantidade a Produzir</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          step="0.001"
                          placeholder="0"
                          data-testid="input-quantidade-produzir"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="text-sm text-muted-foreground">
                  <p><strong>Rendimento padrão:</strong> {selectedReceita?.rendimentoPadrao} {selectedReceita?.unidadeSaida}</p>
                  <p><strong>Estoque atual:</strong> {selectedReceita?.estoqueAtual} {selectedReceita?.unidadeSaida}</p>
                </div>

                {/* Verificação de ingredientes */}
                {form.watch('quantidadeProduzir') && selectedReceita && (
                  <div className="mt-4 p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Verificação de Ingredientes</h4>
                    {(() => {
                      const quantidade = parseFloat(form.watch('quantidadeProduzir')) || 0;
                      const verificacao = checkIngredientesDisponiveis(selectedReceita, quantidade);
                      
                      if (verificacao.disponivel) {
                        return (
                          <div className="flex items-center gap-2 text-green-600">
                            <CheckCircle className="h-4 w-4" />
                            <span>Todos os ingredientes disponíveis</span>
                          </div>
                        );
                      } else {
                        return (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-red-600">
                              <AlertTriangle className="h-4 w-4" />
                              <span>Ingredientes insuficientes:</span>
                            </div>
                            {verificacao.faltantes.map((faltante, index) => (
                              <p key={index} className="text-sm text-red-600 ml-6">
                                • {faltante.nome}: necessário {faltante.necessario} {faltante.unidade}, 
                                disponível {faltante.disponivel}
                              </p>
                            ))}
                          </div>
                        );
                      }
                    })()}
                  </div>
                )}

                <div className="flex justify-end gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsProducaoDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={producaoMutation.isPending}
                    data-testid="button-confirmar-producao"
                  >
                    {producaoMutation.isPending ? "Produzindo..." : "Confirmar Produção"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
