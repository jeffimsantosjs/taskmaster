import { storage } from "../storage";

export class LabelService {
  async generateLabels(pedidoId: string): Promise<{ success: boolean; message: string; pdfUrl?: string }> {
    try {
      const pedido = await storage.getPedido(pedidoId);
      if (!pedido) {
        return { success: false, message: "Pedido não encontrado" };
      }

      // Verificar configuração de impressoras
      const config = await storage.getConfigImpressoras();
      
      if (config?.impressoraRecepcao && config?.impressoraCozinha) {
        // Tentar imprimir nas impressoras configuradas
        try {
          await this.printReceptionLabel(pedido, config.impressoraRecepcao);
          await this.printKitchenLabel(pedido, config.impressoraCozinha);
          
          return { 
            success: true, 
            message: "Etiquetas enviadas para impressão" 
          };
        } catch (printError) {
          // Se falhar na impressão, gerar PDF
          const pdfUrl = await this.generatePDF(pedido);
          return { 
            success: true, 
            message: "Impressoras indisponíveis. PDF gerado.", 
            pdfUrl 
          };
        }
      } else {
        // Gerar PDF se não há impressoras configuradas
        const pdfUrl = await this.generatePDF(pedido);
        return { 
          success: true, 
          message: "Etiquetas geradas em PDF", 
          pdfUrl 
        };
      }
      
    } catch (error) {
      console.error('Erro na geração de etiquetas:', error);
      return { success: false, message: "Erro interno no servidor" };
    }
  }

  private async printReceptionLabel(pedido: any, printerUrl: string): Promise<void> {
    // Simular envio para impressora térmica
    const labelData = {
      type: 'reception',
      pedidoId: pedido.id,
      cliente: pedido.cliente.nome,
      telefone: pedido.cliente.telefone,
      dataEntrega: pedido.dataEntrega,
      observacoes: pedido.observacoes,
      total: pedido.totalLiquido
    };

    // Em um cenário real, faria POST para a impressora
    const response = await fetch(printerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(labelData)
    });

    if (!response.ok) {
      throw new Error('Falha na impressão');
    }
  }

  private async printKitchenLabel(pedido: any, printerUrl: string): Promise<void> {
    // Simular envio para impressora térmica
    const labelData = {
      type: 'kitchen',
      pedidoId: pedido.id,
      cliente: pedido.cliente.nome,
      dataEntrega: pedido.dataEntrega,
      itens: pedido.itens.map((item: any) => ({
        produto: item.produto.nome,
        quantidade: item.quantidade,
        customizacoes: item.customizacoes
      })),
      observacoes: pedido.observacoes
    };

    // Em um cenário real, faria POST para a impressora
    const response = await fetch(printerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(labelData)
    });

    if (!response.ok) {
      throw new Error('Falha na impressão');
    }
  }

  private async generatePDF(pedido: any): Promise<string> {
    // Simulação da geração de PDF
    // Em um cenário real, usaria uma biblioteca como puppeteer ou jsPDF
    
    const pdfContent = {
      reception: {
        title: 'ETIQUETA RECEPÇÃO',
        pedidoId: pedido.id,
        cliente: pedido.cliente.nome,
        telefone: pedido.cliente.telefone,
        dataEntrega: new Date(pedido.dataEntrega).toLocaleString('pt-BR'),
        observacoes: pedido.observacoes,
        total: `R$ ${parseFloat(pedido.totalLiquido).toFixed(2)}`
      },
      kitchen: {
        title: 'ETIQUETA COZINHA',
        pedidoId: pedido.id,
        cliente: pedido.cliente.nome,
        dataEntrega: new Date(pedido.dataEntrega).toLocaleString('pt-BR'),
        itens: pedido.itens.map((item: any) => ({
          produto: item.produto.nome,
          quantidade: item.quantidade,
          customizacoes: item.customizacoes
        })),
        observacoes: pedido.observacoes
      }
    };

    // Em um cenário real, geraria o PDF e salvaria em um local acessível
    // Por enquanto, retorna um URL simulado
    const pdfFileName = `etiquetas_pedido_${pedido.id}_${Date.now()}.pdf`;
    const pdfUrl = `/api/labels/pdf/${pdfFileName}`;
    
    // Aqui salvaria o PDF no servidor ou storage
    console.log('PDF gerado:', pdfContent);
    
    return pdfUrl;
  }
}

export const labelService = new LabelService();
