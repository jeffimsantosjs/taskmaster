import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Topbar } from "@/components/layout/topbar";
import { 
  ShoppingCart, 
  DollarSign, 
  AlertTriangle, 
  Clock,
  TrendingUp,
  TrendingDown,
  Package,
  BookOpen,
  Cookie,
  Users
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";

interface DashboardStats {
  pedidosHoje: number;
  faturamentoHoje: number;
  produtosBaixoEstoque: number;
  pedidosProducao: number;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats']
  });

  const { data: pedidosHoje, isLoading: pedidosLoading } = useQuery({
    queryKey: ['/api/pedidos'],
    select: (data: any[]) => data.slice(0, 5) // Mostrar apenas os 5 mais recentes
  });

  if (statsLoading) {
    return (
      <div>
        <Topbar title="Dashboard" description="Visão geral do sistema" />
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-20 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Topbar title="Dashboard" description="Visão geral do sistema" />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pedidos Hoje</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="stat-pedidos-hoje">
                    {stats?.pedidosHoje || 0}
                  </p>
                  <p className="text-sm text-green-600 mt-1 flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +15% vs ontem
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <ShoppingCart className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Faturamento Hoje</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="stat-faturamento-hoje">
                    {formatCurrency(stats?.faturamentoHoje || 0)}
                  </p>
                  <p className="text-sm text-green-600 mt-1 flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +8% vs ontem
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Produtos em Falta</p>
                  <p className="text-3xl font-bold text-destructive" data-testid="stat-produtos-falta">
                    {stats?.produtosBaixoEstoque || 0}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Requer atenção
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Em Produção</p>
                  <p className="text-3xl font-bold text-accent" data-testid="stat-em-producao">
                    {stats?.pedidosProducao || 0}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Pedidos ativos
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Clock className="h-6 w-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pedidos Recentes */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="border-b">
                <div className="flex items-center justify-between">
                  <CardTitle>Agenda de Pedidos</CardTitle>
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-primary text-primary-foreground">
                      Hoje
                    </Button>
                    <Button size="sm" variant="outline">
                      Semana
                    </Button>
                    <Button size="sm" variant="outline">
                      Mês
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {pedidosLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse p-3 bg-muted rounded-lg h-16"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-foreground">
                      Pedidos para Hoje ({new Date().toLocaleDateString('pt-BR')})
                    </h4>
                    {pedidosHoje?.length ? (
                      pedidosHoje.map((pedido: any) => (
                        <div 
                          key={pedido.id} 
                          className="flex items-center justify-between p-3 bg-muted rounded-lg"
                          data-testid={`pedido-${pedido.id}`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <div>
                              <p className="text-sm font-medium text-foreground">
                                {pedido.cliente?.nome || 'Cliente não informado'}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(pedido.dataEntrega).toLocaleTimeString('pt-BR', {
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })} • {formatCurrency(parseFloat(pedido.totalLiquido))}
                              </p>
                            </div>
                          </div>
                          <Badge 
                            variant={pedido.status === 'PRONTO' ? 'default' : 'secondary'}
                            className={pedido.status === 'PRONTO' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                          >
                            {pedido.status === 'PAGO_CONFIRMADO' && 'Confirmado'}
                            {pedido.status === 'EM_PRODUCAO' && 'Em Produção'}
                            {pedido.status === 'PRONTO' && 'Pronto'}
                            {pedido.status === 'ENTREGUE' && 'Entregue'}
                          </Badge>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        Nenhum pedido para hoje
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar com Alertas e Resumo */}
          <div className="space-y-6">
            {/* Alertas */}
            <Card>
              <CardHeader className="border-b">
                <CardTitle>Alertas</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {stats?.produtosBaixoEstoque > 0 && (
                  <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg border-l-4 border-red-500">
                    <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-red-800">Estoque Baixo</p>
                      <p className="text-xs text-red-600">
                        {stats.produtosBaixoEstoque} item(ns) com estoque baixo
                      </p>
                    </div>
                  </div>
                )}
                {stats?.produtosBaixoEstoque === 0 && (
                  <p className="text-center text-muted-foreground py-4">
                    Nenhum alerta no momento
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Resumo Rápido */}
            <Card>
              <CardHeader className="border-b">
                <CardTitle>Resumo Rápido</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <Package className="h-4 w-4" />
                    Matérias-primas
                  </span>
                  <span className="text-sm font-medium">-- itens</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Receitas ativas
                  </span>
                  <span className="text-sm font-medium">-- receitas</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <Cookie className="h-4 w-4" />
                    Produtos disponíveis
                  </span>
                  <span className="text-sm font-medium">-- produtos</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Clientes cadastrados
                  </span>
                  <span className="text-sm font-medium">-- clientes</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
