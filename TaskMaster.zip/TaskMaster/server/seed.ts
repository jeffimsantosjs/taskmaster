import bcrypt from "bcryptjs";
import { storage } from "./storage";

export async function seedDatabase() {
  try {
    console.log("🌱 Iniciando seed do banco de dados...");

    // 1. Criar usuário admin
    const adminPassword = await bcrypt.hash("admin123", 10);
    const admin = await storage.createUser({
      username: "admin",
      password: adminPassword,
      role: "admin"
    });
    console.log("✅ Usuário admin criado");

    // 2. Criar matérias-primas
    const farinha = await storage.createMateriaPrima({
      nome: "Farinha de Trigo",
      categoria: "Farináceos",
      unidade: "kg",
      estoqueAtual: "50",
      estoqueMinimo: "10",
      custoUnitario: "4.50",
      fornecedor: "Moinho Central"
    });

    const acucar = await storage.createMateriaPrima({
      nome: "Açúcar Cristal",
      categoria: "Adoçantes",
      unidade: "kg",
      estoqueAtual: "30",
      estoqueMinimo: "5",
      custoUnitario: "3.20",
      fornecedor: "Usina São João"
    });

    const leiteCondensado = await storage.createMateriaPrima({
      nome: "Leite Condensado",
      categoria: "Lácteos",
      unidade: "lata",
      estoqueAtual: "24",
      estoqueMinimo: "6",
      custoUnitario: "4.80",
      fornecedor: "Nestlé"
    });

    const cremeLeite = await storage.createMateriaPrima({
      nome: "Creme de Leite",
      categoria: "Lácteos",
      unidade: "lata",
      estoqueAtual: "18",
      estoqueMinimo: "4",
      custoUnitario: "3.50",
      fornecedor: "Nestlé"
    });

    const cacau = await storage.createMateriaPrima({
      nome: "Cacau em Pó",
      categoria: "Chocolates",
      unidade: "kg",
      estoqueAtual: "5",
      estoqueMinimo: "2",
      custoUnitario: "12.00",
      fornecedor: "Garoto"
    });

    const manteiga = await storage.createMateriaPrima({
      nome: "Manteiga sem Sal",
      categoria: "Lácteos",
      unidade: "kg",
      estoqueAtual: "8",
      estoqueMinimo: "2",
      custoUnitario: "15.00",
      fornecedor: "Aviação"
    });

    const ovos = await storage.createMateriaPrima({
      nome: "Ovos",
      categoria: "Proteínas",
      unidade: "duzia",
      estoqueAtual: "15",
      estoqueMinimo: "3",
      custoUnitario: "6.50",
      fornecedor: "Granja Feliz"
    });

    console.log("✅ Matérias-primas criadas");

    // 3. Criar receitas
    const receitaBrigadeiro = await storage.createReceita({
      nome: "Brigadeiro de Cacau",
      descricao: "Brigadeiro tradicional de cacau em pó",
      unidadeSaida: "porção",
      estoqueAtual: "0",
      rendimentoPadrao: "50",
      custoEstimado: "15.00"
    });

    const receitaMassaBolo = await storage.createReceita({
      nome: "Massa de Bolo de Chocolate",
      descricao: "Massa básica para bolo de chocolate",
      unidadeSaida: "unidade",
      estoqueAtual: "0",
      rendimentoPadrao: "1",
      custoEstimado: "25.00"
    });

    console.log("✅ Receitas criadas");

    // 4. Criar itens das receitas
    // Brigadeiro: leite condensado, creme de leite, cacau, manteiga
    await storage.createItemReceita({
      receitaId: receitaBrigadeiro.id,
      materiaPrimaId: leiteCondensado.id,
      quantidade: "2",
      unidade: "lata"
    });

    await storage.createItemReceita({
      receitaId: receitaBrigadeiro.id,
      materiaPrimaId: cremeLeite.id,
      quantidade: "1",
      unidade: "lata"
    });

    await storage.createItemReceita({
      receitaId: receitaBrigadeiro.id,
      materiaPrimaId: cacau.id,
      quantidade: "0.200",
      unidade: "kg"
    });

    await storage.createItemReceita({
      receitaId: receitaBrigadeiro.id,
      materiaPrimaId: manteiga.id,
      quantidade: "0.050",
      unidade: "kg"
    });

    // Massa de bolo: farinha, açúcar, ovos, manteiga, cacau
    await storage.createItemReceita({
      receitaId: receitaMassaBolo.id,
      materiaPrimaId: farinha.id,
      quantidade: "0.300",
      unidade: "kg"
    });

    await storage.createItemReceita({
      receitaId: receitaMassaBolo.id,
      materiaPrimaId: acucar.id,
      quantidade: "0.200",
      unidade: "kg"
    });

    await storage.createItemReceita({
      receitaId: receitaMassaBolo.id,
      materiaPrimaId: ovos.id,
      quantidade: "0.5",
      unidade: "duzia"
    });

    await storage.createItemReceita({
      receitaId: receitaMassaBolo.id,
      materiaPrimaId: manteiga.id,
      quantidade: "0.100",
      unidade: "kg"
    });

    await storage.createItemReceita({
      receitaId: receitaMassaBolo.id,
      materiaPrimaId: cacau.id,
      quantidade: "0.050",
      unidade: "kg"
    });

    console.log("✅ Itens das receitas criados");

    // 5. Criar embalagens
    const potinho = await storage.createEmbalagem({
      nome: "Potinho 120ml",
      tipo: "pote",
      unidade: "unidade",
      estoqueAtual: "200",
      custoUnitario: "0.35"
    });

    const caixaP = await storage.createEmbalagem({
      nome: "Caixa P",
      tipo: "caixa",
      unidade: "unidade",
      estoqueAtual: "50",
      custoUnitario: "1.20"
    });

    const caixaM = await storage.createEmbalagem({
      nome: "Caixa M",
      tipo: "caixa",
      unidade: "unidade",
      estoqueAtual: "30",
      custoUnitario: "1.80"
    });

    const sacolaP = await storage.createEmbalagem({
      nome: "Sacola P",
      tipo: "sacola",
      unidade: "unidade",
      estoqueAtual: "100",
      custoUnitario: "0.15"
    });

    const tagPadrao = await storage.createEmbalagem({
      nome: "Tag Padrão",
      tipo: "tag",
      unidade: "unidade",
      estoqueAtual: "500",
      custoUnitario: "0.05"
    });

    console.log("✅ Embalagens criadas");

    // 6. Criar produtos
    const produtoBrigadeiro = await storage.createProduto({
      nome: "Brigadeiro de Cacau de Colher",
      descricao: "Brigadeiro tradicional servido em potinho de 120ml",
      precoVenda: "8.00",
      unidade: "unidade",
      estoqueAtual: "0"
    });

    const produtoBoloChocolate = await storage.createProduto({
      nome: "Bolo de Chocolate",
      descricao: "Bolo de chocolate tamanho médio",
      precoVenda: "35.00",
      unidade: "unidade",
      estoqueAtual: "0"
    });

    console.log("✅ Produtos criados");

    // 7. Criar componentes dos produtos
    // Brigadeiro: 1 porção da receita + 1 potinho + 1 tag
    await storage.createComponenteProduto({
      produtoId: produtoBrigadeiro.id,
      receitaId: receitaBrigadeiro.id,
      embalagemId: null,
      quantidade: "0.02" // 1/50 da receita (que rende 50 porções)
    });

    await storage.createComponenteProduto({
      produtoId: produtoBrigadeiro.id,
      receitaId: null,
      embalagemId: potinho.id,
      quantidade: "1"
    });

    await storage.createComponenteProduto({
      produtoId: produtoBrigadeiro.id,
      receitaId: null,
      embalagemId: tagPadrao.id,
      quantidade: "1"
    });

    // Bolo: 1 massa + 1 caixa M + 1 tag
    await storage.createComponenteProduto({
      produtoId: produtoBoloChocolate.id,
      receitaId: receitaMassaBolo.id,
      embalagemId: null,
      quantidade: "1"
    });

    await storage.createComponenteProduto({
      produtoId: produtoBoloChocolate.id,
      receitaId: null,
      embalagemId: caixaM.id,
      quantidade: "1"
    });

    await storage.createComponenteProduto({
      produtoId: produtoBoloChocolate.id,
      receitaId: null,
      embalagemId: tagPadrao.id,
      quantidade: "1"
    });

    console.log("✅ Componentes dos produtos criados");

    // 8. Criar clientes
    const cliente1 = await storage.createCliente({
      nome: "Ana Costa",
      telefone: "(11) 99999-1111",
      email: "ana@email.com",
      aniversario: new Date("1990-05-15")
    });

    const cliente2 = await storage.createCliente({
      nome: "João Silva",
      telefone: "(11) 99999-2222",
      email: "joao@email.com",
      aniversario: new Date("1985-08-20")
    });

    const cliente3 = await storage.createCliente({
      nome: "Maria Santos",
      telefone: "(11) 99999-3333",
      email: "maria@email.com",
      aniversario: new Date("1992-12-10")
    });

    console.log("✅ Clientes criados");

    // 9. Criar alguns pedidos
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(14, 0, 0, 0);

    const pedido1 = await storage.createPedido({
      clienteId: cliente1.id,
      canal: "whatsapp",
      dataEntrega: tomorrow,
      status: "PAGO_CONFIRMADO",
      observacoes: "Entregar no portão da frente",
      totalBruto: "85.00",
      desconto: "0.00",
      totalLiquido: "85.00"
    });

    await storage.createItemPedido({
      pedidoId: pedido1.id,
      produtoId: produtoBrigadeiro.id,
      quantidade: "5",
      precoUnit: "8.00",
      customizacoes: { observacao: "Extra cremoso" }
    });

    await storage.createItemPedido({
      pedidoId: pedido1.id,
      produtoId: produtoBoloChocolate.id,
      quantidade: "1",
      precoUnit: "35.00",
      customizacoes: { massa: "chocolate", decoracao: "chantilly" }
    });

    const dayAfterTomorrow = new Date();
    dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);
    dayAfterTomorrow.setHours(16, 30, 0, 0);

    const pedido2 = await storage.createPedido({
      clienteId: cliente2.id,
      canal: "instagram",
      dataEntrega: dayAfterTomorrow,
      status: "PAGO_CONFIRMADO",
      observacoes: "Aniversário, colocar vela",
      totalBruto: "120.00",
      desconto: "5.00",
      totalLiquido: "115.00"
    });

    await storage.createItemPedido({
      pedidoId: pedido2.id,
      produtoId: produtoBoloChocolate.id,
      quantidade: "3",
      precoUnit: "35.00"
    });

    console.log("✅ Pedidos criados");

    console.log("🎉 Seed concluído com sucesso!");
    console.log("👤 Usuário: admin / Senha: admin123");

  } catch (error) {
    console.error("❌ Erro no seed:", error);
    throw error;
  }
}

// Executar seed se chamado diretamente
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase();
}
