import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Link, useLocation } from "wouter";
import {
  BarChart3,
  Package,
  BookOpen,
  Cookie,
  Box,
  Calendar,
  ScanBarcode,
  Users,
  Factory,
  Settings,
  ChefHat,
  PieChart,
  Cake
} from "lucide-react";

const navigation = [
  {
    title: "Dashboard",
    href: "/",
    icon: BarChart3
  },
  {
    title: "Estoque",
    items: [
      {
        title: "Matérias-Primas",
        href: "/materias-primas",
        icon: Package
      },
      {
        title: "Receitas", 
        href: "/receitas",
        icon: BookOpen
      },
      {
        title: "Produtos",
        href: "/produtos", 
        icon: Cookie
      },
      {
        title: "Embalagens",
        href: "/embalagens",
        icon: Box
      }
    ]
  },
  {
    title: "Vendas",
    items: [
      {
        title: "Pedidos Agendados",
        href: "/pedidos",
        icon: Calendar
      },
      {
        title: "Venda Rápida",
        href: "/venda-rapida",
        icon: ScanBarcode
      },
      {
        title: "Clientes",
        href: "/clientes",
        icon: Users
      }
    ]
  },
  {
    title: "Produção",
    items: [
      {
        title: "Produção Receitas",
        href: "/producao/receitas",
        icon: ChefHat
      },
      {
        title: "Produção Produtos", 
        href: "/producao/produtos",
        icon: Factory
      }
    ]
  },
  {
    title: "Relatórios",
    items: [
      {
        title: "Relatórios",
        href: "/relatorios",
        icon: PieChart
      }
    ]
  }
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="flex h-full w-64 flex-col bg-sidebar border-r border-sidebar-border">
      {/* Logo */}
      <div className="flex items-center gap-3 p-6 border-b border-sidebar-border">
        <div className="w-10 h-10 bg-sidebar-primary rounded-lg flex items-center justify-center">
          <Cake className="h-6 w-6 text-sidebar-primary-foreground" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-sidebar-primary">Confeitaria Pro</h1>
          <p className="text-xs text-muted-foreground">Sistema de Gestão</p>
        </div>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 p-4">
        <nav className="space-y-2">
          {navigation.map((section, index) => (
            <div key={index} className="space-y-1">
              {section.href ? (
                // Single item section
                <Link href={section.href}>
                  <Button
                    variant={location === section.href ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-start gap-3",
                      location === section.href && "bg-sidebar-accent text-sidebar-accent-foreground border-l-4 border-l-sidebar-primary"
                    )}
                    data-testid={`nav-${section.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <section.icon className="h-5 w-5" />
                    {section.title}
                  </Button>
                </Link>
              ) : (
                // Section with items
                <>
                  {index > 0 && <div className="pt-4">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-4 pb-2">
                      {section.title}
                    </p>
                  </div>}
                  {section.items?.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <Button
                        variant={location === item.href ? "secondary" : "ghost"}
                        className={cn(
                          "w-full justify-start gap-3",
                          location === item.href && "bg-sidebar-accent text-sidebar-accent-foreground border-l-4 border-l-sidebar-primary"
                        )}
                        data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <item.icon className="h-5 w-5" />
                        {item.title}
                      </Button>
                    </Link>
                  ))}
                </>
              )}
            </div>
          ))}

          <Separator className="my-4" />

          {/* Config Section */}
          <div className="pt-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-4 pb-2">
              Configurações
            </p>
            <Link href="/config/impressoras">
              <Button
                variant={location === "/config/impressoras" ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3",
                  location === "/config/impressoras" && "bg-sidebar-accent text-sidebar-accent-foreground border-l-4 border-l-sidebar-primary"
                )}
                data-testid="nav-impressoras"
              >
                <Settings className="h-5 w-5" />
                Impressoras
              </Button>
            </Link>
          </div>
        </nav>
      </ScrollArea>

      {/* User Profile */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
            <Users className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-sidebar-foreground">Admin</p>
            <p className="text-xs text-muted-foreground">Administrador</p>
          </div>
        </div>
      </div>
    </div>
  );
}
