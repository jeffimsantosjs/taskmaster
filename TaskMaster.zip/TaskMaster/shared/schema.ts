import { sql } from "drizzle-orm";
import { 
  pgTable, 
  text, 
  varchar, 
  decimal, 
  timestamp, 
  json, 
  pgEnum,
  integer 
} from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const statusPedidoEnum = pgEnum('status_pedido', [
  'PAGO_CONFIRMADO',
  'EM_PRODUCAO', 
  'PRONTO',
  'ENTREGUE',
  'CANCELADO'
]);

export const tipoMovimentoEnum = pgEnum('tipo_movimento', [
  'ENTRADA',
  'SAIDA', 
  'PRODUCAO_RECEITA',
  'PRODUCAO_PRODUTO',
  'VENDA',
  'AJUSTE'
]);

// Users table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").default("operacao").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Matéria-prima
export const materiasPrimas = pgTable("materias_primas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  categoria: text("categoria"),
  unidade: text("unidade").notNull(),
  estoqueAtual: decimal("estoque_atual", { precision: 10, scale: 3 }).default("0").notNull(),
  estoqueMinimo: decimal("estoque_minimo", { precision: 10, scale: 3 }).default("0").notNull(),
  custoUnitario: decimal("custo_unitario", { precision: 10, scale: 2 }).default("0").notNull(),
  fornecedor: text("fornecedor"),
  observacoes: text("observacoes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Receitas
export const receitas = pgTable("receitas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  unidadeSaida: text("unidade_saida").notNull(),
  estoqueAtual: decimal("estoque_atual", { precision: 10, scale: 3 }).default("0").notNull(),
  rendimentoPadrao: decimal("rendimento_padrao", { precision: 10, scale: 3 }).default("1").notNull(),
  custoEstimado: decimal("custo_estimado", { precision: 10, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Itens de receita
export const itensReceita = pgTable("itens_receita", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  receitaId: varchar("receita_id").notNull().references(() => receitas.id, { onDelete: 'cascade' }),
  materiaPrimaId: varchar("materia_prima_id").notNull().references(() => materiasPrimas.id, { onDelete: 'cascade' }),
  quantidade: decimal("quantidade", { precision: 10, scale: 3 }).notNull(),
  unidade: text("unidade").notNull()
});

// Produtos
export const produtos = pgTable("produtos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  precoVenda: decimal("preco_venda", { precision: 10, scale: 2 }).default("0").notNull(),
  unidade: text("unidade"),
  estoqueAtual: decimal("estoque_atual", { precision: 10, scale: 3 }).default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Embalagens
export const embalagens = pgTable("embalagens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  tipo: text("tipo"),
  unidade: text("unidade"),
  estoqueAtual: decimal("estoque_atual", { precision: 10, scale: 3 }).default("0").notNull(),
  custoUnitario: decimal("custo_unitario", { precision: 10, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Componentes do produto
export const componentesProduto = pgTable("componentes_produto", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  produtoId: varchar("produto_id").notNull().references(() => produtos.id, { onDelete: 'cascade' }),
  receitaId: varchar("receita_id").references(() => receitas.id, { onDelete: 'cascade' }),
  embalagemId: varchar("embalagem_id").references(() => embalagens.id, { onDelete: 'cascade' }),
  quantidade: decimal("quantidade", { precision: 10, scale: 3 }).notNull()
});

// Movimentos de estoque
export const movimentosEstoque = pgTable("movimentos_estoque", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  data: timestamp("data").defaultNow().notNull(),
  tipo: tipoMovimentoEnum("tipo").notNull(),
  quantidade: decimal("quantidade", { precision: 10, scale: 3 }).notNull(),
  observacao: text("observacao"),
  materiaPrimaId: varchar("materia_prima_id").references(() => materiasPrimas.id),
  receitaId: varchar("receita_id").references(() => receitas.id),
  produtoId: varchar("produto_id").references(() => produtos.id),
  embalagemId: varchar("embalagem_id").references(() => embalagens.id)
});

// Clientes
export const clientes = pgTable("clientes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  telefone: text("telefone"),
  email: text("email"),
  aniversario: timestamp("aniversario"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Pedidos
export const pedidos = pgTable("pedidos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clienteId: varchar("cliente_id").notNull().references(() => clientes.id),
  canal: text("canal"),
  dataEntrega: timestamp("data_entrega").notNull(),
  status: statusPedidoEnum("status").default('PAGO_CONFIRMADO').notNull(),
  observacoes: text("observacoes"),
  totalBruto: decimal("total_bruto", { precision: 10, scale: 2 }).default("0").notNull(),
  desconto: decimal("desconto", { precision: 10, scale: 2 }).default("0").notNull(),
  totalLiquido: decimal("total_liquido", { precision: 10, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Itens do pedido
export const itensPedido = pgTable("itens_pedido", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pedidoId: varchar("pedido_id").notNull().references(() => pedidos.id, { onDelete: 'cascade' }),
  produtoId: varchar("produto_id").notNull().references(() => produtos.id),
  quantidade: decimal("quantidade", { precision: 10, scale: 3 }).default("1").notNull(),
  precoUnit: decimal("preco_unit", { precision: 10, scale: 2 }).default("0").notNull(),
  customizacoes: json("customizacoes")
});

// Configurações de impressoras
export const configImpressoras = pgTable("config_impressoras", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  impressoraRecepcao: text("impressora_recepcao"),
  impressoraCozinha: text("impressora_cozinha"),
  etiquetaLarguraMm: integer("etiqueta_largura_mm"),
  etiquetaAlturaMm: integer("etiqueta_altura_mm"),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertMateriaPrimaSchema = createInsertSchema(materiasPrimas).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertReceitaSchema = createInsertSchema(receitas).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertItemReceitaSchema = createInsertSchema(itensReceita).omit({
  id: true
});

export const insertProdutoSchema = createInsertSchema(produtos).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertEmbalagemSchema = createInsertSchema(embalagens).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertComponenteProdutoSchema = createInsertSchema(componentesProduto).omit({
  id: true
});

export const insertClienteSchema = createInsertSchema(clientes).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertPedidoSchema = createInsertSchema(pedidos).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertItemPedidoSchema = createInsertSchema(itensPedido).omit({
  id: true
});

export const insertConfigImpressorasSchema = createInsertSchema(configImpressoras).omit({
  id: true,
  updatedAt: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MateriaPrima = typeof materiasPrimas.$inferSelect;
export type InsertMateriaPrima = z.infer<typeof insertMateriaPrimaSchema>;

export type Receita = typeof receitas.$inferSelect;
export type InsertReceita = z.infer<typeof insertReceitaSchema>;

export type ItemReceita = typeof itensReceita.$inferSelect;
export type InsertItemReceita = z.infer<typeof insertItemReceitaSchema>;

export type Produto = typeof produtos.$inferSelect;
export type InsertProduto = z.infer<typeof insertProdutoSchema>;

export type Embalagem = typeof embalagens.$inferSelect;
export type InsertEmbalagem = z.infer<typeof insertEmbalagemSchema>;

export type ComponenteProduto = typeof componentesProduto.$inferSelect;
export type InsertComponenteProduto = z.infer<typeof insertComponenteProdutoSchema>;

export type MovimentoEstoque = typeof movimentosEstoque.$inferSelect;

export type Cliente = typeof clientes.$inferSelect;
export type InsertCliente = z.infer<typeof insertClienteSchema>;

export type Pedido = typeof pedidos.$inferSelect;
export type InsertPedido = z.infer<typeof insertPedidoSchema>;

export type ItemPedido = typeof itensPedido.$inferSelect;
export type InsertItemPedido = z.infer<typeof insertItemPedidoSchema>;

export type ConfigImpressoras = typeof configImpressoras.$inferSelect;
export type InsertConfigImpressoras = z.infer<typeof insertConfigImpressorasSchema>;
