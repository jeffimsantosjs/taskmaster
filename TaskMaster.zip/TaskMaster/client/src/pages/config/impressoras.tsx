import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Topbar } from "@/components/layout/topbar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { configImpressorasSchema } from "@/lib/validations";
import type { ConfigImpressoras } from "@shared/schema";
import { Printer, Settings, TestTube, Wifi, WifiOff } from "lucide-react";

export default function ConfigImpressoras() {
  const [testingConnection, setTestingConnection] = useState<'reception' | 'kitchen' | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: config, isLoading } = useQuery<ConfigImpressoras>({
    queryKey: ['/api/config/impressoras']
  });

  const form = useForm({
    resolver: zodResolver(configImpressorasSchema),
    defaultValues: {
      impressoraRecepcao: "",
      impressoraCozinha: "",
      etiquetaLarguraMm: "",
      etiquetaAlturaMm: ""
    }
  });

  // Sincronizar dados do servidor com o formulário
  useState(() => {
    if (config) {
      form.reset({
        impressoraRecepcao: config.impressoraRecepcao || "",
        impressoraCozinha: config.impressoraCozinha || "",
        etiquetaLarguraMm: config.etiquetaLarguraMm?.toString() || "",
        etiquetaAlturaMm: config.etiquetaAlturaMm?.toString() || ""
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (data: any) => {
      const formattedData = {
        ...data,
        etiquetaLarguraMm: data.etiquetaLarguraMm ? parseInt(data.etiquetaLarguraMm) : undefined,
        etiquetaAlturaMm: data.etiquetaAlturaMm ? parseInt(data.etiquetaAlturaMm) : undefined
      };
      return apiRequest('PUT', '/api/config/impressoras', formattedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/config/impressoras'] });
      toast({
        title: "Sucesso",
        description: "Configurações salvas com sucesso"
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  });

  const handleSubmit = form.handleSubmit((data) => {
    updateMutation.mutate(data);
  });

  const testConnection = async (type: 'reception' | 'kitchen') => {
    setTestingConnection(type);
    
    try {
      const url = type === 'reception' 
        ? form.getValues('impressoraRecepcao')
        : form.getValues('impressoraCozinha');

      if (!url) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Configure a URL da impressora primeiro"
        });
        return;
      }

      // Simular teste de conexão
      // Em um cenário real, faria uma requisição para testar a impressora
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simular sucesso/falha aleatoriamente para demonstração
      const success = Math.random() > 0.3;
      
      if (success) {
        toast({
          title: "Conexão OK",
          description: `Impressora ${type === 'reception' ? 'de recepção' : 'da cozinha'} conectada com sucesso`
        });
      } else {
        toast({
          variant: "destructive",
          title: "Falha na conexão",
          description: `Não foi possível conectar à impressora ${type === 'reception' ? 'de recepção' : 'da cozinha'}`
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro de teste",
        description: "Erro ao testar conexão com a impressora"
      });
    } finally {
      setTestingConnection(null);
    }
  };

  if (isLoading) {
    return (
      <div>
        <Topbar 
          title="Configuração de Impressoras" 
          description="Configure impressoras para etiquetas"
          showQuickActions={false}
        />
        <div className="p-6">
          <Card>
            <CardContent className="p-8">
              <div className="flex items-center justify-center">
                <div className="text-lg">Carregando configurações...</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Topbar 
        title="Configuração de Impressoras" 
        description="Configure impressoras para etiquetas"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Info Card */}
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Settings className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900">Como funciona?</h3>
                <p className="text-sm text-blue-700 mt-1">
                  Configure as URLs/IPs das impressoras térmicas para impressão automática de etiquetas. 
                  Se não houver impressoras configuradas, as etiquetas serão geradas em PDF para download.
                </p>
                <div className="mt-3 text-sm text-blue-700">
                  <p><strong>Recepção:</strong> Etiqueta que o cliente leva (comprovante)</p>
                  <p><strong>Cozinha:</strong> Etiqueta para iniciar a produção</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Configuration Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Printer className="h-5 w-5" />
              Configuração das Impressoras
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Impressora de Recepção */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                      <Printer className="h-4 w-4 text-green-600" />
                    </div>
                    <h3 className="font-semibold">Impressora de Recepção</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-2">
                      <FormField
                        control={form.control}
                        name="impressoraRecepcao"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>URL/IP da Impressora</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="http://192.168.1.100:9100 ou IP da impressora térmica"
                                data-testid="input-impressora-recepcao"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex items-end">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => testConnection('reception')}
                        disabled={testingConnection === 'reception' || !form.watch('impressoraRecepcao')}
                        className="w-full"
                        data-testid="button-test-reception"
                      >
                        {testingConnection === 'reception' ? (
                          <>
                            <TestTube className="h-4 w-4 mr-2 animate-spin" />
                            Testando...
                          </>
                        ) : (
                          <>
                            <TestTube className="h-4 w-4 mr-2" />
                            Testar
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Impressora da Cozinha */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Printer className="h-4 w-4 text-orange-600" />
                    </div>
                    <h3 className="font-semibold">Impressora da Cozinha</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-2">
                      <FormField
                        control={form.control}
                        name="impressoraCozinha"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>URL/IP da Impressora</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="http://192.168.1.101:9100 ou IP da impressora térmica"
                                data-testid="input-impressora-cozinha"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex items-end">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => testConnection('kitchen')}
                        disabled={testingConnection === 'kitchen' || !form.watch('impressoraCozinha')}
                        className="w-full"
                        data-testid="button-test-kitchen"
                      >
                        {testingConnection === 'kitchen' ? (
                          <>
                            <TestTube className="h-4 w-4 mr-2 animate-spin" />
                            Testando...
                          </>
                        ) : (
                          <>
                            <TestTube className="h-4 w-4 mr-2" />
                            Testar
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Configurações de Etiqueta */}
                <div className="space-y-4 pt-6 border-t">
                  <h3 className="font-semibold">Dimensões das Etiquetas</h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="etiquetaLarguraMm"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Largura (mm)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              placeholder="62"
                              data-testid="input-largura-etiqueta"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="etiquetaAlturaMm"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Altura (mm)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              placeholder="29"
                              data-testid="input-altura-etiqueta"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <p className="text-xs text-muted-foreground">
                    Dimensões comuns: 62x29mm, 58x60mm, 80x60mm
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end gap-4 pt-6 border-t">
                  <Button
                    type="submit"
                    disabled={updateMutation.isPending}
                    data-testid="button-salvar-config"
                  >
                    {updateMutation.isPending ? "Salvando..." : "Salvar Configurações"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold">Impressora de Recepção</h4>
                  <p className="text-sm text-muted-foreground">
                    {config?.impressoraRecepcao || "Não configurada"}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {config?.impressoraRecepcao ? (
                    <>
                      <Wifi className="h-5 w-5 text-green-500" />
                      <span className="text-sm text-green-600">Configurada</span>
                    </>
                  ) : (
                    <>
                      <WifiOff className="h-5 w-5 text-gray-400" />
                      <span className="text-sm text-muted-foreground">Pendente</span>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold">Impressora da Cozinha</h4>
                  <p className="text-sm text-muted-foreground">
                    {config?.impressoraCozinha || "Não configurada"}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {config?.impressoraCozinha ? (
                    <>
                      <Wifi className="h-5 w-5 text-green-500" />
                      <span className="text-sm text-green-600">Configurada</span>
                    </>
                  ) : (
                    <>
                      <WifiOff className="h-5 w-5 text-gray-400" />
                      <span className="text-sm text-muted-foreground">Pendente</span>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Help Card */}
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                <TestTube className="h-4 w-4 text-yellow-600" />
              </div>
              <div>
                <h4 className="font-semibold text-yellow-900">Dicas de Configuração</h4>
                <div className="text-sm text-yellow-700 mt-2 space-y-1">
                  <p>• Para impressoras Epson TM-T20, use: http://IP_DA_IMPRESSORA:9100</p>
                  <p>• Para impressoras Bematech MP-4200, configure via software do fabricante</p>
                  <p>• Verifique se as impressoras estão na mesma rede Wi-Fi</p>
                  <p>• Se não tiver impressoras, deixe os campos vazios - as etiquetas serão geradas em PDF</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
