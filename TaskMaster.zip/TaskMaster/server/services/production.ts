import { storage } from "../storage";
import type { MateriaPrima, Receita, Produto, Embalagem } from "@shared/schema";

export class ProductionService {
  async produzirReceita(receitaId: string, quantidadeProduzir: number): Promise<{ success: boolean; message: string }> {
    try {
      // 1. Buscar receita
      const receita = await storage.getReceita(receitaId);
      if (!receita) {
        return { success: false, message: "Receita não encontrada" };
      }

      // 2. Buscar itens da receita
      const itensReceita = await storage.getItensReceita(receitaId);
      if (itensReceita.length === 0) {
        return { success: false, message: "Receita não possui ingredientes" };
      }

      // 3. Verificar se há matéria-prima suficiente
      const errosEstoque = [];
      for (const item of itensReceita) {
        const qtdNecessaria = (parseFloat(item.quantidade) * quantidadeProduzir) / parseFloat(receita.rendimentoPadrao);
        const estoqueAtual = parseFloat(item.materiaPrima.estoqueAtual);
        
        if (estoqueAtual < qtdNecessaria) {
          errosEstoque.push(`${item.materiaPrima.nome}: necessário ${qtdNecessaria}${item.unidade}, disponível ${estoqueAtual}${item.materiaPrima.unidade}`);
        }
      }

      if (errosEstoque.length > 0) {
        return { 
          success: false, 
          message: `Estoque insuficiente:\n${errosEstoque.join('\n')}` 
        };
      }

      // 4. Executar produção (baixar matérias-primas e dar entrada na receita)
      for (const item of itensReceita) {
        const qtdNecessaria = (parseFloat(item.quantidade) * quantidadeProduzir) / parseFloat(receita.rendimentoPadrao);
        const novoEstoque = parseFloat(item.materiaPrima.estoqueAtual) - qtdNecessaria;
        
        // Atualizar estoque da matéria-prima
        await storage.updateEstoqueMateriaPrima(item.materiaPrimaId, novoEstoque);
        
        // Registrar movimento de saída
        await storage.createMovimentoEstoque({
          tipo: 'SAIDA',
          quantidade: qtdNecessaria.toString(),
          observacao: `Produção receita: ${receita.nome}`,
          materiaPrimaId: item.materiaPrimaId,
          receitaId: null,
          produtoId: null,
          embalagemId: null
        });
      }

      // 5. Dar entrada na receita
      const novoEstoqueReceita = parseFloat(receita.estoqueAtual) + quantidadeProduzir;
      await storage.updateEstoqueReceita(receitaId, novoEstoqueReceita);
      
      // Registrar movimento de entrada
      await storage.createMovimentoEstoque({
        tipo: 'PRODUCAO_RECEITA',
        quantidade: quantidadeProduzir.toString(),
        observacao: `Produção de ${quantidadeProduzir} ${receita.unidadeSaida}`,
        materiaPrimaId: null,
        receitaId: receitaId,
        produtoId: null,
        embalagemId: null
      });

      return { 
        success: true, 
        message: `Produção realizada com sucesso: ${quantidadeProduzir} ${receita.unidadeSaida}` 
      };
      
    } catch (error) {
      console.error('Erro na produção de receita:', error);
      return { success: false, message: "Erro interno no servidor" };
    }
  }

  async produzirProduto(produtoId: string, quantidadeProduzir: number): Promise<{ success: boolean; message: string }> {
    try {
      // 1. Buscar produto
      const produto = await storage.getProduto(produtoId);
      if (!produto) {
        return { success: false, message: "Produto não encontrado" };
      }

      // 2. Buscar componentes do produto
      const componentes = await storage.getComponentesProduto(produtoId);
      if (componentes.length === 0) {
        return { success: false, message: "Produto não possui componentes configurados" };
      }

      // 3. Verificar estoques de receitas e embalagens
      const errosEstoque = [];
      
      for (const componente of componentes) {
        const qtdNecessaria = parseFloat(componente.quantidade) * quantidadeProduzir;
        
        if (componente.receita) {
          const estoqueAtual = parseFloat(componente.receita.estoqueAtual);
          if (estoqueAtual < qtdNecessaria) {
            errosEstoque.push(`Receita ${componente.receita.nome}: necessário ${qtdNecessaria}, disponível ${estoqueAtual}`);
          }
        }
        
        if (componente.embalagem) {
          const estoqueAtual = parseFloat(componente.embalagem.estoqueAtual);
          if (estoqueAtual < qtdNecessaria) {
            errosEstoque.push(`Embalagem ${componente.embalagem.nome}: necessário ${qtdNecessaria}, disponível ${estoqueAtual}`);
          }
        }
      }

      if (errosEstoque.length > 0) {
        return { 
          success: false, 
          message: `Estoque insuficiente:\n${errosEstoque.join('\n')}` 
        };
      }

      // 4. Executar produção (baixar receitas/embalagens e dar entrada no produto)
      for (const componente of componentes) {
        const qtdNecessaria = parseFloat(componente.quantidade) * quantidadeProduzir;
        
        if (componente.receita) {
          const novoEstoque = parseFloat(componente.receita.estoqueAtual) - qtdNecessaria;
          await storage.updateEstoqueReceita(componente.receitaId!, novoEstoque);
          
          await storage.createMovimentoEstoque({
            tipo: 'SAIDA',
            quantidade: qtdNecessaria.toString(),
            observacao: `Produção produto: ${produto.nome}`,
            materiaPrimaId: null,
            receitaId: componente.receitaId,
            produtoId: null,
            embalagemId: null
          });
        }
        
        if (componente.embalagem) {
          const novoEstoque = parseFloat(componente.embalagem.estoqueAtual) - qtdNecessaria;
          await storage.updateEstoqueEmbalagem(componente.embalagemId!, novoEstoque);
          
          await storage.createMovimentoEstoque({
            tipo: 'SAIDA',
            quantidade: qtdNecessaria.toString(),
            observacao: `Produção produto: ${produto.nome}`,
            materiaPrimaId: null,
            receitaId: null,
            produtoId: null,
            embalagemId: componente.embalagemId
          });
        }
      }

      // 5. Dar entrada no produto
      const novoEstoqueProduto = parseFloat(produto.estoqueAtual) + quantidadeProduzir;
      await storage.updateEstoqueProduto(produtoId, novoEstoqueProduto);
      
      await storage.createMovimentoEstoque({
        tipo: 'PRODUCAO_PRODUTO',
        quantidade: quantidadeProduzir.toString(),
        observacao: `Produção de ${quantidadeProduzir} unidades`,
        materiaPrimaId: null,
        receitaId: null,
        produtoId: produtoId,
        embalagemId: null
      });

      return { 
        success: true, 
        message: `Produção realizada com sucesso: ${quantidadeProduzir} unidades` 
      };
      
    } catch (error) {
      console.error('Erro na produção de produto:', error);
      return { success: false, message: "Erro interno no servidor" };
    }
  }

  async produzirPedidos(dataInicio: Date, dataFim: Date): Promise<{ success: boolean; message: string }> {
    try {
      // 1. Buscar pedidos no período com status PAGO_CONFIRMADO
      const pedidos = await storage.getPedidos({
        dataInicio,
        dataFim,
        status: 'PAGO_CONFIRMADO'
      });

      if (pedidos.length === 0) {
        return { success: false, message: "Nenhum pedido encontrado no período" };
      }

      // 2. Para cada pedido, buscar os itens e verificar se há produtos em estoque
      let pedidosProcessados = 0;
      const erros = [];

      for (const pedido of pedidos) {
        const pedidoCompleto = await storage.getPedido(pedido.id);
        if (!pedidoCompleto) continue;

        try {
          // Verificar se há estoque para todos os itens do pedido
          const errosEstoque = [];
          
          for (const item of pedidoCompleto.itens) {
            const qtdNecessaria = parseFloat(item.quantidade);
            const estoqueAtual = parseFloat(item.produto.estoqueAtual);
            
            if (estoqueAtual < qtdNecessaria) {
              errosEstoque.push(`Produto ${item.produto.nome}: necessário ${qtdNecessaria}, disponível ${estoqueAtual}`);
            }
          }

          if (errosEstoque.length > 0) {
            erros.push(`Pedido ${pedido.id}: ${errosEstoque.join(', ')}`);
            continue;
          }

          // Se há estoque, processar o pedido
          for (const item of pedidoCompleto.itens) {
            const qtdNecessaria = parseFloat(item.quantidade);
            const novoEstoque = parseFloat(item.produto.estoqueAtual) - qtdNecessaria;
            
            await storage.updateEstoqueProduto(item.produtoId, novoEstoque);
            
            await storage.createMovimentoEstoque({
              tipo: 'SAIDA',
              quantidade: qtdNecessaria.toString(),
              observacao: `Pedido ${pedido.id} - ${pedido.cliente.nome}`,
              materiaPrimaId: null,
              receitaId: null,
              produtoId: item.produtoId,
              embalagemId: null
            });
          }

          // Atualizar status do pedido
          await storage.updatePedido(pedido.id, { status: 'EM_PRODUCAO' });
          pedidosProcessados++;

        } catch (error) {
          erros.push(`Pedido ${pedido.id}: erro no processamento`);
        }
      }

      let message = `${pedidosProcessados} pedidos colocados em produção`;
      if (erros.length > 0) {
        message += `\n\nErros:\n${erros.join('\n')}`;
      }

      return { success: true, message };
      
    } catch (error) {
      console.error('Erro na produção de pedidos:', error);
      return { success: false, message: "Erro interno no servidor" };
    }
  }

  async vendaRapida(produtoId: string, quantidade: number): Promise<{ success: boolean; message: string }> {
    try {
      const produto = await storage.getProduto(produtoId);
      if (!produto) {
        return { success: false, message: "Produto não encontrado" };
      }

      const estoqueAtual = parseFloat(produto.estoqueAtual);
      if (estoqueAtual < quantidade) {
        return { 
          success: false, 
          message: `Estoque insuficiente. Disponível: ${estoqueAtual}, solicitado: ${quantidade}` 
        };
      }

      // Baixar do estoque
      const novoEstoque = estoqueAtual - quantidade;
      await storage.updateEstoqueProduto(produtoId, novoEstoque);

      // Registrar movimento
      await storage.createMovimentoEstoque({
        tipo: 'VENDA',
        quantidade: quantidade.toString(),
        observacao: 'Venda rápida (balcão)',
        materiaPrimaId: null,
        receitaId: null,
        produtoId: produtoId,
        embalagemId: null
      });

      return { 
        success: true, 
        message: `Venda realizada: ${quantidade} ${produto.unidade || 'unidades'}` 
      };
      
    } catch (error) {
      console.error('Erro na venda rápida:', error);
      return { success: false, message: "Erro interno no servidor" };
    }
  }
}

export const productionService = new ProductionService();
