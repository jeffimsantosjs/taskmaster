import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTable } from "@/components/ui/data-table";
import { Topbar } from "@/components/layout/topbar";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Pedido, Cliente, Produto, MovimentoEstoque } from "@shared/schema";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Package, 
  DollarSign,
  Calendar,
  Download,
  Filter
} from "lucide-react";
import type { ColumnDef } from "@tanstack/react-table";

export default function Relatorios() {
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  
  const [selectedPeriod, setSelectedPeriod] = useState("mes-atual");

  const { data: pedidos } = useQuery<(Pedido & { cliente: Cliente })[]>({
    queryKey: ['/api/pedidos', dateRange],
    queryFn: () => {
      const params = new URLSearchParams({
        dataInicio: dateRange.start,
        dataFim: dateRange.end
      });
      return fetch(`/api/pedidos?${params}`, { credentials: 'include' })
        .then(res => res.json());
    }
  });

  const { data: clientes } = useQuery<Cliente[]>({
    queryKey: ['/api/clientes']
  });

  const { data: produtos } = useQuery<Produto[]>({
    queryKey: ['/api/produtos']
  });

  const { data: movimentos } = useQuery<MovimentoEstoque[]>({
    queryKey: ['/api/movimentos', dateRange],
    queryFn: () => {
      // Em um cenário real, haveria uma rota para buscar movimentos
      // Por ora, vamos simular alguns dados básicos
      return [];
    }
  });

  // Cálculos financeiros
  const calcularFinanceiro = () => {
    const pedidosEntregues = pedidos?.filter(p => p.status === 'ENTREGUE') || [];
    const totalReceita = pedidosEntregues.reduce((sum, p) => sum + parseFloat(p.totalLiquido), 0);
    const totalPedidos = pedidosEntregues.length;
    const ticketMedio = totalPedidos > 0 ? totalReceita / totalPedidos : 0;

    return {
      receita: totalReceita,
      pedidos: totalPedidos,
      ticketMedio
    };
  };

  // Melhores clientes
  const calcularMelhoresClientes = () => {
    const clienteStats: Record<string, { cliente: Cliente; total: number; pedidos: number; ultimoPedido: Date }> = {};
    
    pedidos?.filter(p => p.status === 'ENTREGUE').forEach(pedido => {
      const clienteId = pedido.clienteId;
      if (!clienteStats[clienteId]) {
        clienteStats[clienteId] = {
          cliente: pedido.cliente,
          total: 0,
          pedidos: 0,
          ultimoPedido: new Date(pedido.dataEntrega)
        };
      }
      
      clienteStats[clienteId].total += parseFloat(pedido.totalLiquido);
      clienteStats[clienteId].pedidos += 1;
      
      const dataPedido = new Date(pedido.dataEntrega);
      if (dataPedido > clienteStats[clienteId].ultimoPedido) {
        clienteStats[clienteId].ultimoPedido = dataPedido;
      }
    });

    return Object.values(clienteStats)
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);
  };

  // Produtos mais vendidos (simulado - precisaria de uma tabela de itens de pedido)
  const calcularMelhoresProdutos = () => {
    // Simulação baseada nos produtos disponíveis
    return produtos?.map(produto => ({
      produto,
      quantidadeVendida: Math.floor(Math.random() * 50) + 1,
      receita: parseFloat(produto.precoVenda) * (Math.floor(Math.random() * 50) + 1)
    }))
    .sort((a, b) => b.quantidadeVendida - a.quantidadeVendida)
    .slice(0, 10) || [];
  };

  // Aniversariantes
  const getAniversariantes = (mes?: number) => {
    const targetMonth = mes ?? new Date().getMonth();
    return clientes?.filter(cliente => {
      if (!cliente.aniversario) return false;
      return new Date(cliente.aniversario).getMonth() === targetMonth;
    }) || [];
  };

  const handlePeriodChange = (period: string) => {
    setSelectedPeriod(period);
    const today = new Date();
    
    switch (period) {
      case 'hoje':
        setDateRange({
          start: today.toISOString().split('T')[0],
          end: today.toISOString().split('T')[0]
        });
        break;
      case 'semana':
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - 7);
        setDateRange({
          start: weekStart.toISOString().split('T')[0],
          end: today.toISOString().split('T')[0]
        });
        break;
      case 'mes-atual':
        setDateRange({
          start: new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0],
          end: today.toISOString().split('T')[0]
        });
        break;
      case 'trimestre':
        const quarterStart = new Date(today);
        quarterStart.setMonth(today.getMonth() - 3);
        setDateRange({
          start: quarterStart.toISOString().split('T')[0],
          end: today.toISOString().split('T')[0]
        });
        break;
    }
  };

  const financeiro = calcularFinanceiro();
  const melhoresClientes = calcularMelhoresClientes();
  const melhoresProdutos = calcularMelhoresProdutos();
  const aniversariantes = getAniversariantes();

  const clientesColumns: ColumnDef<any>[] = [
    {
      header: "Cliente",
      cell: ({ row }) => row.original.cliente.nome
    },
    {
      header: "Pedidos",
      cell: ({ row }) => row.original.pedidos
    },
    {
      header: "Total",
      cell: ({ row }) => formatCurrency(row.original.total)
    },
    {
      header: "Ticket Médio",
      cell: ({ row }) => formatCurrency(row.original.total / row.original.pedidos)
    },
    {
      header: "Último Pedido",
      cell: ({ row }) => formatDate(row.original.ultimoPedido)
    }
  ];

  const produtosColumns: ColumnDef<any>[] = [
    {
      header: "Produto",
      cell: ({ row }) => row.original.produto.nome
    },
    {
      header: "Quantidade",
      cell: ({ row }) => row.original.quantidadeVendida
    },
    {
      header: "Receita",
      cell: ({ row }) => formatCurrency(row.original.receita)
    },
    {
      header: "Preço Médio",
      cell: ({ row }) => formatCurrency(parseFloat(row.original.produto.precoVenda))
    }
  ];

  return (
    <div>
      <Topbar 
        title="Relatórios" 
        description="Análise de dados e indicadores"
        showQuickActions={false}
      />
      
      <div className="p-6 space-y-6">
        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-4">
              <Select value={selectedPeriod} onValueChange={handlePeriodChange}>
                <SelectTrigger className="w-48" data-testid="select-periodo">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hoje">Hoje</SelectItem>
                  <SelectItem value="semana">Últimos 7 dias</SelectItem>
                  <SelectItem value="mes-atual">Mês atual</SelectItem>
                  <SelectItem value="trimestre">Último trimestre</SelectItem>
                  <SelectItem value="personalizado">Período personalizado</SelectItem>
                </SelectContent>
              </Select>
              
              {selectedPeriod === "personalizado" && (
                <div className="flex gap-2">
                  <Input
                    type="date"
                    value={dateRange.start}
                    onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                    data-testid="input-data-inicio"
                  />
                  <Input
                    type="date"
                    value={dateRange.end}
                    onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                    data-testid="input-data-fim"
                  />
                </div>
              )}
              
              <Button variant="outline" className="ml-auto">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="financeiro" className="space-y-4">
          <TabsList>
            <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
            <TabsTrigger value="clientes">Clientes</TabsTrigger>
            <TabsTrigger value="produtos">Produtos</TabsTrigger>
            <TabsTrigger value="aniversariantes">Aniversariantes</TabsTrigger>
          </TabsList>

          <TabsContent value="financeiro" className="space-y-4">
            {/* Financial KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Receita Total</p>
                      <p className="text-2xl font-bold" data-testid="receita-total">
                        {formatCurrency(financeiro.receita)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <BarChart3 className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Pedidos</p>
                      <p className="text-2xl font-bold" data-testid="total-pedidos">
                        {financeiro.pedidos}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <TrendingUp className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Ticket Médio</p>
                      <p className="text-2xl font-bold" data-testid="ticket-medio">
                        {formatCurrency(financeiro.ticketMedio)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Período</p>
                      <p className="text-sm font-bold">
                        {formatDate(dateRange.start)} a {formatDate(dateRange.end)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* DRE Simplificado */}
            <Card>
              <CardHeader>
                <CardTitle>Demonstrativo Simplificado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium">Receita Bruta</span>
                    <span className="font-bold">{formatCurrency(financeiro.receita)}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="text-muted-foreground">(-) Descontos</span>
                    <span className="text-muted-foreground">
                      {formatCurrency(pedidos?.reduce((sum, p) => sum + parseFloat(p.desconto), 0) || 0)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-2 border-primary">
                    <span className="font-bold text-lg">Receita Líquida</span>
                    <span className="font-bold text-lg text-primary">
                      {formatCurrency(financeiro.receita)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="clientes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Ranking dos Melhores Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <DataTable
                  columns={clientesColumns}
                  data={melhoresClientes}
                  searchPlaceholder="Buscar clientes..."
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="produtos" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Produtos Mais Vendidos</CardTitle>
              </CardHeader>
              <CardContent>
                <DataTable
                  columns={produtosColumns}
                  data={melhoresProdutos}
                  searchPlaceholder="Buscar produtos..."
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="aniversariantes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {Array.from({ length: 12 }, (_, i) => {
                const mesAniversariantes = getAniversariantes(i);
                const nomesMeses = [
                  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
                ];
                
                return (
                  <Card key={i}>
                    <CardHeader>
                      <CardTitle className="text-lg">{nomesMeses[i]}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {mesAniversariantes.length > 0 ? (
                        <div className="space-y-2">
                          {mesAniversariantes.map(cliente => (
                            <div 
                              key={cliente.id}
                              className="flex items-center justify-between p-2 bg-muted rounded"
                            >
                              <span className="font-medium">{cliente.nome}</span>
                              <span className="text-sm text-muted-foreground">
                                {formatDate(cliente.aniversario!)}
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-center text-muted-foreground py-4">
                          Nenhum aniversariante
                        </p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
